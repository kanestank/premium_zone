<?php
    $otp = rand(1111,9999);
?>