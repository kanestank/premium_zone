<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" sizes="76x76" href="Premium Mobile Zone Logo.png">
    <link rel="icon" type="image/png" href="Premium Mobile Zone Logo.png">

    <title>Premium Mobile Zone</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- login -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">

    <script src="https://kit.fontawesome.com/a61c319403.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  
   <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!--CSS Files-->
    <link href="assets/css/mystyle.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css1/templatemo-digimedia-v1.css">
    <link rel="stylesheet" href="assets/css1/animated.css">
    <link rel="stylesheet" href="assets/css1/owl.css">

<div style="display: none;"> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    import swal from 'sweetalert';
</div>

</head>
<body>
<div class="fixed-top">
        <!-- Topbar Start -->
        <div class="container-fluid topbar px-0 px-lg-4 bglight py-2 d-none d-lg-block">
            <div class="container">
                <div class="row gx-0 align-items-center">
                    <div class="col-lg-8 text-center text-lg-start mb-lg-0">
                        <div class="d-flex flex-wrap">
                            <div class="border-end border-primary pe-3">
                                <a href="https://maps.app.goo.gl/sjMboxvG99Pr2cha6" class="tezt"><i class="fas fa-map-marker-alt myprimary me-2"></i>Find A Location</a>
                            </div>
                            <div class="ps-3">
                                <a href="https://mail.google.com/" class="tezt"><i class="fas fa-envelope myprimary me-2"></i>premium2024@gmail.com</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center text-lg-end">
                        <div class="d-flex justify-content-end">
                            <div class="d-flex border-end border-primary pe-3">
                                <a class="btn p-0 myprimary me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn p-0 myprimary me-3" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn p-0 myprimary me-3" href="#"><i class="fab fa-instagram"></i></a>
                                <a class="btn p-0 myprimary me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                            <div class="dropdown ms-3">
                                <a href="#" class="dropdown-toggle tezt" data-bs-toggle="dropdown"><small><i class="fas fa-globe-europe myprimary me-2"></i> English</small></a>
                                <div class="dropdown-menu rounded">
                                    <a href="#" class="dropdown-item">English</a>
                                    <a href="#" class="dropdown-item">tamil</a>
                                    <a href="#" class="dropdown-item">sinhala</a>
                                    <a href="#" class="dropdown-item">Arabic</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->

        <!-- Navbar & Hero Start -->
        <div class="container-fluid nav-bar px-0 px-lg-4 py-lg-0">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a href="#" class="navbar-brand p-0">
                <h1 class="myprimary1 mb-0"><img src="Premium Mobile Zone Logo.png"> Premium</h1>
                <!-- <img src="img/logo.png" alt="Logo"> -->
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-0 mx-lg-auto">
                    <?php if (!isset($_SESSION["user_id"])==true){ ?>

                        <a href="index.php" class="nav-item nav-link active">Home</a>
                    <?php }else{ ?>
                        <a href="home.php" class="nav-item nav-link active">Home</a>
                    <?php } ?>
                    
                    <a href="about.php" class="nav-item nav-link">About</a>
                    
                    <?php if (!isset($_SESSION["user_id"])): ?>
                        <a href="login.php" class="nav-item nav-link">Shop</a>
                    <?php else: ?>
                        <a href="shop.php?msg" class="nav-item nav-link ">Shop</a>
                    <?php endif; ?>
                    
                      <div class="nav-item dropdown">
                        <a href="#" class="nav-link" data-bs-toggle="dropdown">
                            <span class="dropdown-toggle">Pages</span>
                        </a>
                        <div class="dropdown-menu">
                            <a href="team.php" class="dropdown-item">Our Team</a>
                            <a href="testimonial.php" class="dropdown-item">Testimonial</a>
                        </div>
                    </div>
                    
                    <a href="contact.php" class="nav-item nav-link">Contact</a>

                    <div class="nav-btn px-3">
                        <a  href="search.php"><i class="fas fa-search"></i></a>
                        
                        <?php if (!isset($_SESSION["user_id"])): ?>
                            <a href="login.php" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0">Login</a>
                        <?php else: ?>
                            <?php
                            $select_cart_number = mysqli_query($conn, "SELECT * FROM `cart` WHERE user_id = '$user_id'") or die('query failed');
                            $cart_rows_number = mysqli_num_rows($select_cart_number);
                            ?>
                            <a href="cart.php" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0">Cart <span>(<?php echo $cart_rows_number; ?>)</span></a>
                            <a href="user_page.php" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0"> <?php echo $_SESSION['user_name']; ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="d-none d-xl-flex flex-shrink-0 ps-4">
                <a href="https://www.facebook.com/profile.php?id=100009193732870&mibextid=LQQJ4d" class="btn btn-light btn-lg-square rounded-circle position-relative wow tada" data-wow-delay=".9s">
                    <i class="fa fa-phone-alt fa-2x"></i>
                    <div class="position-absolute" style="top: 7px; right: 12px;">
                        <span><i class="fa fa-comment-dots "></i></span>
                    </div>
                </a>
            </div>
        </nav>
    </div>
</div>
</div>
