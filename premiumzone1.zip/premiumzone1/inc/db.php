<?php

$server = "localhost";
$username = "ictlk_premium";
$password = "Premium@123";
$db = "ictlk_premium";

$conn = new mysqli($server, $username, $password, $db);

?>