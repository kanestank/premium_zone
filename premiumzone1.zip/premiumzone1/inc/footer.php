
<!-- Back to Top -->
<a href="#" class="btn btn1-lg btn1 text-white btn1-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

 <!-- Scripts -->
  <script src="assets/js/jquery/jquery.min.js"></script>
  <script src="assets/js/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/js/owl-carousel.js"></script>
  <script src="assets/js/js/animation.js"></script>
  <script src="assets/js/js/imagesloaded.js"></script>
  <script src="assets/js/js/custom.js"></script>

<!-- Template Javascript -->
<script src="assets/js/main.js"></script>
<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
</body>

</html>