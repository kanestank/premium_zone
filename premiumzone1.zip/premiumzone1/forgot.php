<?php
session_start();
include "inc/header.php";
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style type="text/css">
    .login-forms .login-form-content .button input{
    color: #fff;
    background: #002366;
    border-radius: 6px;

    padding: 0;
    cursor: pointer;
    transition: all 0.4s ease;
  }
  </style>
</head>
<body>
  <!-- Password Reset 8 - Bootstrap Brain Component -->
<div class=" py-3 mt-5"></div>
<section class=" p-3 p-md-4 mt-5 p-xl-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-xxl-11">
        <div class="card border-light-subtle shadow-sm">
          <div class="row g-0">
            <div class="col-12 col-md-6">
              <img class="img-fluid rounded-start w-100 h-100 object-fit-cover" loading="lazy" src="forgot.jpg" alt="Welcome back you've been missed!">
            </div>
            <div class="col-12 col-md-6 d-flex align-items-center justify-content-center">
              <div class="col-12 col-lg-11 col-xl-10">
                <div class="card-body p-3 p-md-4 p-xl-5">
                  <div class="row">
                    <div class="col-12">
                      <div class="mb-5">
                        <div class="text-center mb-4">
                          <a href="#!">
                            <img src="icon.jpg" alt="BootstrapBrain Logo" width="200" height="150">
                          </a>
                        </div>
                        <h2 class="h4 text-center">Password Reset</h2>
                        <h3 class="fs-6 fw-normal text-secondary text-center m-0">Provide the email address associated with your account to recover your password.</h3>
                      </div>
                    </div>
                  </div>
                  <form method="post">
                    <div class="row gy-3 overflow-hidden">
                      <div class="col-12">
                        <div class="form-floating mb-3">
                          <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
                          <label for="email" class="form-label">Email</label>
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="d-grid">
                          
                          <button type = "submit" name = "btnVerify" style="display: inline-block; background-color: darkblue; color: #fff; text-align: center; font-size: 1.00rem; padding: 0.5rem 1rem; text-decoration: none; border-radius: 0.25rem;">Verify</button>
                        </div>
                      </div>
                    </div>
                  </form>
                  <div class="row">
                    <div class="col-12">
                      <div class="d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-center mt-5">
                     <a href="login.php" style="display: inline-block; background-color: darkblue; color: #fff; text-align: center; font-size: 1.00rem; padding: 0.5rem 1rem; text-decoration: none; border-radius: 0.25rem;">Login</a>

                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>

<?php
  if (isset($_POST['btnVerify'])) {
    include 'inc/db.php';
    include 'otp.php';

    $_SESSION['otp'] = $otp;

    $otpemail = mysqli_query($conn,"SELECT * FROM users WHERE email = '$_POST[email]'");

    $otpemailrow = mysqli_fetch_assoc($otpemail);

    $_SESSION['userid'] = $otpemailrow['id'];

    if(mysqli_num_rows($otpemail) > 0){
        echo "<div style='display: none;'>";
        //Load Composer's autoloader
        require 'phpmailer/vendor/autoload.php';

        //Create an instance; passing `true` enables exceptions
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'premiumzone2024@gmail.com';                     //SMTP username
            $mail->Password   = 'ywehrznjxzgzdbwt';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

            //Recipients
            $mail->setFrom('premiumzone2024@gmail.com', 'premium');
            $mail->addAddress($_POST['email'], 'kane');     //Add a recipient



            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Your OTP';
            $mail->Body    = 'Your OTP Number is :'.$otp;
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            echo 'Message has been sent';
            echo '<script>window.location.href="otpcode.php"</script>';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
          echo "</div>";
    }
    else{
      echo "<script>alert('Invaild Email Address')</script>";
    }

  }
?>