<div style="display: none;"> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    import swal from 'sweetalert';
</div>
<?php
session_start();
include("inc/db.php");

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}

if (isset($_POST['add_to_cart'])) {

    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_quantity = $_POST['product_quantity'];

    $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    if (mysqli_num_rows($check_cart_numbers) > 0) {
        $message[] = 'Already Added to Cart!';
    } else {
        mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, quantity, image) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
        $message[] = 'Book Added to Cart!';
    }

}

if (isset($_POST['subscribe'])) {

    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $subscribe = mysqli_query($conn, "SELECT email FROM `subscriber` WHERE email = '$email'") or die('query failed');

    if (mysqli_num_rows($subscribe) > 0) {
        echo "<script>
                  swal('email already exixts!');
                  </script>";

    } else {
        $add_subscriber = mysqli_query($conn, "INSERT INTO `subscriber`(email) VALUES('$email')") or die('query failed');

        if ($add_subscriber) {
             echo "<script>
        swal({
            title: 'Success!',
            text: 'Thanks for ur Subscribing',
            icon: 'success',
            timer: 1500,
            buttons: false
        });
    </script>";
        } else {
            echo "<script>
        alert('Something went wrong. Please try again!');
      </script>";
        }
    }
}

?>

<?php
include "inc/header.php";
?>

<style>
    .category:hover {
        background: darkblue;
        transition: all 0.5s;
        border-radius: 15px;
    }

    .icon {
        color: blue;
    }

    .category:hover .icon,
    .category:hover h5 {
        color: #fff;
    }


    .content {
        padding: 7rem 0;
    }

    h2 {
        font-size: 20px;
    }

    .bg-left-half {
        position: relative;
    }

    .bg-left-half:before {
        position: absolute;
        width: 50%;
        height: 100%;
        z-index: -1;
        content: "";
        left: 0;
        top: 0;
        background-color: #f8f9fa;
    }

    .media-29101 {
        padding: 10px;
    }

    .media-29101 img {
        margin-bottom: 10px;
    }

    .media-29101 h3 {
        font-size: 18px;
        font-weight: 900 !important;
    }

    .media-29101 h3 a {
        color: #6c757d;
    }

    .owl-2-style .owl-nav {
        display: none;
    }

    .owl-2-style .owl-dots {
        text-align: center;
        position: relative;
        bottom: -30px;
    }

    .owl-2-style .owl-dots .owl-dot {
        display: inline-block;
    }

    .owl-2-style .owl-dots .owl-dot span {
        display: inline-block;
        width: 15px;
        height: 3px;
        border-radius: 0px;
        background: #cccccc;
        -webkit-transition: 0.3s all cubic-bezier(0.32, 0.71, 0.53, 0.53);
        -o-transition: 0.3s all cubic-bezier(0.32, 0.71, 0.53, 0.53);
        transition: 0.3s all cubic-bezier(0.32, 0.71, 0.53, 0.53);
        margin: 3px;
    }

    .owl-2-style .owl-dots .owl-dot.active span {
        background: #007bff;
    }

    .owl-2-style .owl-dots .owl-dot:active,
    .owl-2-style .owl-dots .owl-dot:focus {
        outline: none;
    }

    .banner {
        background: url('images/banner-1.jpg');
        background-size: cover;
    }
</style>
<!--Slider-->
<script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-25b3ccb0-1d56-4d8f-9974-5d8413b78364" data-elfsight-app-lazy></div>
<div class="container" id="MainSlider">
    <div class="container" id="myslider">
        <div id="carouselExampleAutoplaying" class="carousel slide carousel-fade" data-bs-ride="carousel" data-aos-duration="200">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/slider/slider-1.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slider/slider-2.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slider/slider-3.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="assets/img/slider/slider-4.jpg" class="d-block w-100" alt="...">
                </div>
            </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
    </div>
    <div class="container mt-3" id="SecondSlider">
        <div id="myslider2">
            <div id="carouselExampleAutoplaying" class="carousel slide carousel-fade" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="assets/img/slider/slider-sm-1.jpg" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="assets/img/slider/slider-sm-2.jpg" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="assets/img/slider/slider-sm-3.jpg" class="d-block w-100" alt="...">
                    </div>
                </div>
                  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                  </button>
            </div>
        </div>
        <div>
            <img src="assets/img/slider/offers.jpg" id="myoffer">
        </div>
    </div>
</div>
<!--End of Slider-->


<!--Offers area-->
<div class="container-fluid" id="offerarea" data-aos="fade-up" data-aos-duration="500">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <span>More resons to shop</span>
                    <div class="d-flex flex-row">
                      <div class="pt-2"><img src="assets/img/offers/offer-1.jpg"></div>
                      <div class="p-2"><img src="assets/img/offers/offer-2.jpg"></div>
                    </div>
                    <div class="d-flex flex-row">
                      <div class="pt-1"><img src="assets/img/offers/offer-3.jpg"></div>
                      <div class="p-2 pt-1"><img src="assets/img/offers/offer-4.jpg"></div>
                    </div>
            </div>
            <div class="col-md-4">
                <span>Workout must-haves</span>
                <div class="d-flex flex-row">
                      <div class="pt-2"><img src="assets/img/offers/center_offer.jpg"></div>
                </div>
            </div>
            <div class="col-md-4">
                <span>Bank Offers</span>
                <div class="d-flex flex-column">
                  <div class="pt-2"><img src="assets/img/offers/bank-1.jpg"></div>
                  <div class="pt-4"><img src="assets/img/offers/bank-2.jpg"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End of offer-->

<!--welcome-->
 <div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                <div class="row">
                  <div class="col-lg-12">
                    <h1>Premium Mobile Zone</h1>
                    <h2>Get More About Premium Mobile Zone</h2>
                    <p>We hold the Major awards from All Famous Smart Phones brands in SriLanka.The Most Awarded Mobile Partner in SriLanka.We Specialize In Major Brands Of MOBILES & MOBILE ACCESSORIES and bring you Only the Best in Quality</p>
                  </div>
                  <div class="col-lg-12">
                    <div class="border-first-button scroll-to-section">
                      <a href="shop.php">Shop Now</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                <img src="assets/images/Payment Information.gif" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!--welcome-->

<!-- Categories Start -->
<div id="portfolio" class="our-portfolio section">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="section-heading wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.3s">
                    <h6>Our Category</h6>
                    <h4>See Our Recent <em>Brands</em></h4>
                    <div class="line-dec"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid wow fadeIn" data-wow-duration="1s" data-wow-delay="0.7s">
        <div class="row">
            <div class="col-lg-12">
                <div class="loop owl-carousel">
                    <?php
                    include("inc/db.php");
                    $select_category = mysqli_query($conn, "SELECT * FROM `category`") or die('query failed');
                    if (mysqli_num_rows($select_category) > 0) {
                        while ($fetch_category = mysqli_fetch_assoc($select_category)) {
                            ?>
                           <div class="item">
                                <a href="shop.php?msg&ID=<?php echo $fetch_category['cat_id']?>">
                                    <div class="portfolio-item">
                                         <img src="uploaded_img/<?php echo htmlspecialchars($fetch_category['cat_image']); ?>" alt="Portfolio Image">
                                        <div class="down-content">
                                            <h4><?php echo $fetch_category['cat_icon']; ?></h4>
                                            
                                        </div>
                                    </div>
                                </a>  
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="empty">No portfolio items added yet!</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Categories End -->

<!-- About Start -->
  <div id="" class="about section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6">
              <div class="about-left-image  wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                <img src="assets/images/Refund.gif" alt="">
              </div>
            </div>
            <div class="col-lg-6 align-self-center  wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="about-right-content">
                <div class="section-heading">
                  <h6>About Us</h6>
                  <h4>Who is Premium Mobile <em>zone</em></h4>
                  <div class="line-dec"></div>
                </div>
                <p> Welcome to Premium Mobile Zone , where the love for literature comes to life! Established in [1985], we are more than just a premium Mobile store; we are a haven for bibliophiles and a community dedicated to the written word.We provide ourselves on offering a diverse and inclusive range of phones that cater to readers of all tastes and preferences.</p>
                <div class="row">
                  <div class="col-lg-4 col-sm-4">
                    <div class="skill-item first-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                      <div class="progress" data-percentage="90">
                        <span class="progress-left">
                          <span class="progress-bar"></span>
                        </span>
                        <span class="progress-right">
                          <span class="progress-bar"></span>
                        </span>
                        <div class="progress-value">
                          <div>
                            90%<br>
                            <span>Customer Service</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-sm-4">
                    <div class="skill-item second-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                      <div class="progress" data-percentage="80">
                        <span class="progress-left">
                          <span class="progress-bar"></span>
                        </span>
                        <span class="progress-right">
                          <span class="progress-bar"></span>
                        </span>
                        <div class="progress-value">
                          <div>
                            80%<br>
                            <span>Reparing</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-sm-4">
                    <div class="skill-item third-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                      <div class="progress" data-percentage="80">
                        <span class="progress-left">
                          <span class="progress-bar"></span>
                        </span>
                        <span class="progress-right">
                          <span class="progress-bar"></span>
                        </span>
                        <div class="progress-value">
                          <div>
                            80%<br>
                            <span>Satisfaction</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a class="btn1 text-white btn-outline-primary py-3 px-5 mt-2" href="about.php">Read More</a>
                </div> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- About End -->

<!-- Books Start -->

    <div id="" class="services section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading  wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.5s">
            <h6>Our Services</h6>
            <h4>What Our PremiumZone <em>Provides</em></h4>
            <div class="line-dec"></div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                <div class="col-lg-12">
                  <div class="menu">
                    <div class="first-thumb active">
                      <div class="thumb">
                        <span class="icon"><img src="assets/images/service-icon-01.png" alt=""></span>
                        Phones
                      </div>
                    </div>
                    <div>
                      <div class="thumb">                 
                        <span class="icon"><img src="assets/images/service-icon-02.png" alt=""></span>
                        Phone &amp; Accesories
                      </div>
                    </div>
                    <div>
                      <div class="thumb">                 
                        <span class="icon"><img src="assets/images/service-icon-03.png" alt=""></span>
                        Laptops
                      </div>
                    </div>
                    <div>
                      <div class="thumb">                 
                        <span class="icon"><img src="assets/images/service-icon-04.png" alt=""></span>
                        Speakers
                      </div>
                    </div>
                    
                  </div>
                </div> 
                <div class="col-lg-12">
                  <ul class="nacc">
                    <li class="active">
                      <div>
                        <div class="thumb">
                          <div class="row">
                            <div class="col-lg-6 align-self-center">
                              <div class="left-text">
                                <h4>Mobile Phones &amp; Daily Reports</h4>
                                <p>A SmartPhone is A cellular Telephone with An Integrated Computer and Other Features not Originally Associated with Telephones..We Are Provide Some NEW Brands </p>
                                <div class="ticks-list"><span><i class="fa fa-check"></i> APPLE</span> <span><i class="fa fa-check"></i> SAMSUNG</span> <span><i class="fa fa-check"></i>VIVO</span>
                                  <span><i class="fa fa-check"></i> REDMI</span> <span><i class="fa fa-check"></i> OPPO</span> <span><i class="fa fa-check"></i> REALME</span></div>
                                <p>OUR MOBILE BRANDS ARE HERE.............</p>
                              </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                              <div class="right-image">
                                <img src="assets/images/services-image.jpg" alt="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <div class="row">
                            <div class="col-lg-6 align-self-center">
                              <div class="left-text">
                                <h4>Phone &amp; Accessories</h4>
                                <p>The Phone Accessories With the most Demand  Some Of the Top Phone accessories Include phone pouches,Cases and Covers ,Screen guards and Protectors,Wireless Chargers,EarPhones And Head Phones and Powerbanks...  </p>
                                <div class="ticks-list"><span><i class="fa fa-check"></i> PowerBank</span> <span><i class="fa fa-check"></i> Air Buds</span> <span><i class="fa fa-check"></i> Head Phones</span>
                                  <span><i class="fa fa-check"></i> Tempet Glasses</span> <span><i class="fa fa-check"></i> Battery</span> <span><i class="fa fa-check"></i>Screen Protector</span></div>
                                <p>We are Providing These accssories To Our Valuable Customers</p>
                              </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                              <div class="right-image">
                                <img src="assets/images/services-image-02.jpg" alt="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <div class="row">
                            <div class="col-lg-6 align-self-center">
                              <div class="left-text">
                                <h4>New &amp; Laptops</h4>
                                <p>laptops are Designed to be Portbale Computers They are Smaller nd Lighterthan Desktops. The Name connotes the User ability To put the Computer In the lap While they use it</p>
                                <div class="ticks-list"><span><i class="fa fa-check"></i>  Apple MAC</span> <span><i class="fa fa-check"></i>Hp</span> <span><i class="fa fa-check"></i> DEll</span>
                                  <span><i class="fa fa-check"></i> AlienWare </span> <span><i class="fa fa-check"></i> Asus</span> <span><i class="fa fa-check"></i>Lenovao</span></div>
                                <p>Laptop have Recharegable betterys That can be used  for a set of periods Away from a power sources .</p>
                              </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                              <div class="right-image">
                                <img src="assets/images/services-image-03.jpg" alt="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <div class="row">
                            <div class="col-lg-6 align-self-center">
                              <div class="left-text">
                                <h4>Online Shopping &amp;Speakers</h4>
                                <p>High Quality Audio Products That combine advanced Technology With style Design.</p>
                                <div class="ticks-list"><span><i class="fa fa-check"></i> JBL</span> <span><i class="fa fa-check"></i> SONY</span> <span><i class="fa fa-check"></i> Lenovo</span>
                                  <span><i class="fa fa-check"></i> APPLE</span> <span><i class="fa fa-check"></i> SAMSUNG</span> <span><i class="fa fa-check"></i> Nokia</span></div>
                                <p>We are Provide These Speakers</p>
                              </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                              <div class="right-image">
                                <img src="assets/images/services-image-04.jpg" alt="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <div class="row">
                            <div class="col-lg-6 align-self-center">
                              <div class="left-text">
                                <h4>Enjoy &amp; Travel</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sedr do eiusmod deis tempor incididunt ut labore et dolore kengan darwin doerski token.
                                  dover lipsum lorem and the others.</p>
                                <div class="ticks-list"><span><i class="fa fa-check"></i> Optimized Template</span> <span><i class="fa fa-check"></i> Data Info</span> <span><i class="fa fa-check"></i> SEO Analysis</span>
                                  <span><i class="fa fa-check"></i> Data Info</span> <span><i class="fa fa-check"></i> SEO Analysis</span> <span><i class="fa fa-check"></i> Optimized Template</span></div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sedr do eiusmod deis tempor incididunt.</p>
                              </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                              <div class="right-image">
                                <img src="assets/images/services-image.jpg" alt="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>          
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Banner-2 Start -->
 <div id="" class="free-quote">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 offset-lg-4">
          <div class="section-heading  wow fadeIn" data-wow-duration="1s" data-wow-delay="0.3s">
            <h6>NEWSLETTER TO GET IN TOUCH</h6>
            <h4>Join the Premium Community</h4>
            <div class="line-dec"></div>
          </div>
        </div>
        <div class="col-lg-8 offset-lg-1  wow fadeIn" data-wow-duration="1s" data-wow-delay="0.8s">
          <form id="search" action="#" method="POST">
            <div class="row">
            
              <div class="col-lg-8 col-sm-2">
                <fieldset>
                  <input type="email" name="email" class="email" placeholder="Email Address..." autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-4 col-sm-4">
                <fieldset>
                  <button type="submit" name="subscribe" class="main-button">subscribe</button>
                </fieldset>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  
  <footer id="footer">
    <h2>Mobile Shop &copy; all rights reserved<a href="team.php"> NDICT STUDENTS</a></h2>
  </footer>

       
<?php
include "inc/footer.php";
?>

<!-- Banner-2 End -->



<!--JavaScript-->
<script src="assets/js/main.js"></script>
<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Template Javascript -->
<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
  <!-- Scripts -->
  <script src="assets/js/jquery/jquery.min.js"></script>
  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/js/owl-carousel.js"></script>
  <script src="assets/js/js/animation.js"></script>
  <script src="assets/js/js/imagesloaded.js"></script>
  <script src="assets/js/js/custom.js"></script>

<!--Initial aos-->

<script>
    AOS.init();
</script>
<script>
    $(function () {

        if ($('.owl-2').length > 0) {
            $('.owl-2').owlCarousel({
                center: false,
                items: 1,
                loop: true,
                stagePadding: 0,
                margin: 20,
                smartSpeed: 1000,
                autoplay: true,
                nav: true,
                dots: true,
                pauseOnHover: false,
                responsive: {
                    600: {
                        margin: 20,
                        nav: true,
                        items: 2
                    },
                    1000: {
                        margin: 20,
                        stagePadding: 0,
                        nav: true,
                        items: 3
                    }
                }
            });
        }

    })
</script>
