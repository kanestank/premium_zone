<?php
include 'inc/db.php';
session_start();

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}
?>

<?php
include "inc/header.php";
?>

 <style type="text/css">
    :root {
    --primary:  #726ae3;
    --light: #F0FBFC;
    --dark: #181d38;
}

.fw-medium {
    font-weight: 600 !important;
}

.fw-semi-bold {
    font-weight: 700 !important;
}

/*** Button ***/
.btn {
    font-family: 'Nunito', sans-serif;
    font-weight: 600;
    transition: .5s;
    border-radius: 10px;

}
.btn:hover{
    background: #726ae3;
    color:  #FFFFFF ;
    border: none;
}
.btn-outline-primary{
    color: #002366;
    border-color: #002366;
}
/*** Section Title ***/
.section-title {
    position: relative;
    display: inline-block;
    text-transform: uppercase;
}
.section-title::before {
    position: absolute;
    content: "";
    width: calc(100% + 80px);
    height: 2px;
    top: 4px;
    left: -40px;
    background: var(--primary);
    z-index: -1;
}

.section-title::after {
    position: absolute;
    content: "";
    width: calc(100% + 120px);
    height: 2px;
    bottom: 5px;
    left: -60px;
    background: var(--primary);
    z-index: -1;
}

.section-title.text-start::before {
    width: calc(100% + 40px);
    left: 0;
}

.section-title.text-start::after {
    width: calc(100% + 60px);
    left: 0;
}

/*** Service ***/
.service-item {
    background:#dae9fe;
    transition: .5s;
}

.service-item:hover {
    margin-top: -10px;
    background: #726ae3;
}

.service-item * {
    transition: .5s;
}

.service-item:hover * {
    cursor: pointer;
    color: var(--light) !important;
}
/* The container <div> */
.langWrap {
    position: relative;
    display: inline-block;
}


.dropbtn {
    background-color: black; 
    color: white;
    padding: 10px 20px; 
    font-size: 10px;
    border: none;
    cursor: pointer; 
    border-radius: 5px; 
}


.dropdown-content {
    display: none; 
    position: absolute; 
    background-color: white;
    min-width: 160px; 
    z-index: 1; 
    border-radius: 5px; 
}


.dropdown-content a {
    color: black; 
    padding: 12px 16px; 
    text-decoration: none; 
    display: block; 
}


.dropdown-content a:hover {
    background-color: gray;
}

.langWrap:hover .dropdown-content {
    display: block;
}

.langWrap:hover .dropbtn {
    background-color: gray; 
}
    </style>
    <!-- Service Start -->
    <div class="py-5 mt-5"></div>
        <div class="langWrap">
    <button class="dropbtn">Select Language</button>
    <div class="dropdown-content">
        <a href="#" language='english' class="active">English</a>
        <a href="#" language='tamil'>Tamil</a>
        <a href="#" language='sinhala'>Shinhala</a>
    </div>
</div>
    <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-darkblue px-3">About Us</h6>
                <h1 class="mb-5"> About</h1>
            </div>
    <div class="container-xxl py-3 mt-2">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-3 col-sm-6 wow fadeInUp " data-wow-delay="0.1s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-graduation-cap  mb-4" style="color: #726ae3;"></i>
                            <h5 class="mb-4 t1">Our Mission</h5>
                            <p class="p1">"At Premium Mobile Zone, we are passionate about bringing the joy of reading to Mobile enthusiasts all around the world.<br>Our mission is to curate a diverse collection of phones that captivate inspire, Band transport readers new"</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp " data-wow-delay="0.3s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-globe mb-4"  style="color: #726ae3;"></i>
                            <h5 class="mb-3 t2">Our Vission</h5>
                            <p class="p2">"We are One Stop Mobile. Our service-oriented organisation is committed to offering partners the best possible solution on a daily basis, with their wishes and requirements as the primary focus.fostering connectivity and innovation in every hand.we us"</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp " data-wow-delay="0.5s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-home  mb-4"  style="color: #726ae3;"></i>
                            <h5 class="mb-3 t3">Our Collection</h5>
                            <p class="p3">Explore our carefully curated selection of novels,spanning various geners from classic literature to contemporary fiction,mystery,romance and more.Our Shelves are filled with timeless classic and hidden gems waiting to be discovered.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp " data-wow-delay="0.7s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                           <i class='fas fa-user-friends mb-4' style="font-size:48px; color: #726ae3;"></i>
                            <h5 class="mb-3 t4">Our Team</h5>
                            <p class="p4">"Meet the passionate individuals behinds Premium Mobile Zone.Our team is composed of phones lovers who are commited to creating an enriching reading experience for our customers.We value the love of literature and hare that passion with you."</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->


    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="logo.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start  pe-3" style="color: #002366;">About Us</h6>
                    <h1 class="mb-5 title">Welcome to Premium Mobile Zone</h1>
                    <p class="mb-4 description">Welcome to Premium Mobile Zone , where the love for literature comes to life! Established in [1985], we are more than just a premium Mobile store; we are a haven for bibliophiles and a community dedicated to the written word.We provide ourselves on offering a diverse and inclusive range of phones that cater to readers of all tastes and preferences.Join our reading community! Follow us on social media,participate in phones clubs,and stay updated on literary events happening both online and in-store.</p>
                    <p class="mb-5 description2">Our team is dedicated to providing exceptional customer service.Whether you need a phones recommendation or assistance with your order,we're here to help.Founded in 2021,Premium Mobile Zone is not just a mobile store;it's a community of avid readers, writers,and storytellers.We belive in the power of phones to foster i,aginations,empathy,and a deeeper understanding of the world around us.</p>
                
                    <a class="btn btn-outline-primary py-3 px-5 mt-2 bt" href="contact.php">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

<footer id="footer">
    <h2>Mobile Shop &copy; all rights reserved<a href="team.php"> NDICT STUDENTS</a></h2>
  </footer>
       
<?php
include "inc/footer.php";
?>



<script>
        const langEl = document.querySelector('.langWrap');
        const link = document.querySelectorAll('a');
        const titleEl = document.querySelector('.title');
        const descrEl = document.querySelector('.description');
        const descrEl2 = document.querySelector('.description2');
        const bt1=document.querySelector('.bt');

        const xt1 = document.querySelector('.t1');
        const xt2 = document.querySelector('.t2');  
        const xt3 = document.querySelector('.t3');
        const xt4 = document.querySelector('.t4');


        const xp1 = document.querySelector('.p1');
        const xp2 = document.querySelector('.p2');  
        const xp3 = document.querySelector('.p3');
        const xp4 = document.querySelector('.p4');

        const xbt = document.querySelector('.bt');

        link.forEach(el => {
            el.addEventListener('click', () => {
                langEl.querySelector('.active').classList.remove('active');
                el.classList.add('active');

                const attr = el.getAttribute('language');

                titleEl.textContent = data[attr].title;
                descrEl.textContent = data[attr].description;
                descrEl2.textContent = data[attr].description2;

                 xt1.textContent = data[attr].t1;
                 xt2.textContent = data[attr].t2;
                 xt3.textContent = data[attr].t3;
                 xt4.textContent = data[attr].t4;

                 xp1.textContent = data[attr].p1;
                 xp2.textContent = data[attr].p2;
                 xp3.textContent = data[attr].p3;
                 xp4.textContent = data[attr].p4;

                xbt.textContent=data[attr].bt;
            });
        });
        
        var data = {
              "english": 
              {
                "title": "Welcome to Premium Mobile Zone",
                "description": 
                    "Welcome to Premium Mobile Zone , where the love for literature comes to life! Established in [1985], we are more than just a premium Mobile store; we are a haven for bibliophiles and a community dedicated to the written word.We provide ourselves on offering a diverse and inclusive range of phones that cater to readers of all tastes and preferences.Join our reading community! Follow us on social media,participate in phones clubs,and stay updated on literary events happening both online and in-store.",

                 "description2":"Our team is dedicated to providing exceptional customer service.Whether you need a phones recommendation or assistance with your order,we're here to help.Founded in 2021,Premium Mobile Zone is not just a mobile store;it's a community of avid readers, writers,and storytellers.We belive in the power of phones to foster i,aginations,empathy,and a deeeper understanding of the world around us. ",
                 "t1":"Our Mission",

                 "p1":" At Premium Mobile Zone, we are passionate about bringing the joy of reading to Mobile enthusiasts all around the world.<br>Our mission is to curate a diverse collection of phones that captivate inspire, Band transport readers new",

                 "t2":"Our Vission ",

                 "p2":" We are One Stop Mobile. Our service-oriented organisation is committed to offering partners the best possible solution on a daily basis, with their wishes and requirements as the primary focus.fostering connectivity and innovation in every hand.we us",

                 "t3":"Our Collection ",

                 "p3":"Explore our carefully curated selection of novels,spanning various geners from classic literature to contemporary fiction,mystery,romance and more.Our Shelves are filled with timeless classic and hidden gems waiting to be discovered. ",

                 "t4":" Our Team",

                 "p4":" Meet the passionate individuals behinds Premium Mobile Zone.Our team is composed of phones lovers who are commited to creating an enriching reading experience for our customers.We value the love of literature and hare that passion with you.",

                 "bt":"Contact Us"
              },
              "tamil": 
              {
                "title": "பிரீமியம் மொபைல் மண்டலத்திற்கு வரவேற்கிறோம்",

                "description": 
                    "பிரீமியம் மொபைல் மண்டலத்திற்கு வரவேற்கிறோம், அங்கு இலக்கியத்தின் மீதான காதல் உயிர்ப்பிக்கிறது! [1985] இல் நிறுவப்பட்டது, நாங்கள் ஒரு பிரீமியம் மொபைல் ஸ்டோரை விட அதிகம்; நாங்கள் புத்தகங்களை எழுதுபவர்களுக்கான புகலிடமாகவும், எழுதப்பட்ட வார்த்தைகளுக்காக அர்ப்பணிக்கப்பட்ட சமூகமாகவும் இருக்கிறோம். அனைத்து ரசனைகள் மற்றும் விருப்பத்தேர்வுகள் உள்ள வாசகர்களுக்குத் தேவையான பலதரப்பட்ட மற்றும் உள்ளடக்கிய ஃபோன்களை நாங்கள் வழங்குகிறோம். எங்கள் வாசிப்பு சமூகத்தில் சேரவும்! சமூக ஊடகங்களில் எங்களைப் பின்தொடரவும், ஃபோன்கள் கிளப்புகளில் பங்கேற்கவும், ஆன்லைனிலும் கடையிலும் நடக்கும் இலக்கிய நிகழ்வுகளைப் பற்றிய புதுப்பித்த நிலையில் இருக்கவும்.",

                 "description2":"எங்கள் குழு விதிவிலக்கான வாடிக்கையாளர் சேவையை வழங்குவதற்கு அர்ப்பணித்துள்ளது.உங்கள் ஆர்டருக்கு ஃபோன்கள் பரிந்துரை அல்லது உதவி தேவைப்பட்டாலும், நாங்கள் உதவ இங்கே இருக்கிறோம்.2021 இல் நிறுவப்பட்டது, பிரீமியம் மொபைல் மண்டலம் ஒரு மொபைல் ஸ்டோர் மட்டுமல்ல; இது ஆர்வமுள்ள வாசகர்களின் சமூகம், எழுத்தாளர்கள், மற்றும் கதைசொல்லிகள். நான், உணர்ச்சிகள், பச்சாதாபம் மற்றும் நம்மைச் சுற்றியுள்ள உலகத்தைப் பற்றிய ஆழமான புரிதலை வளர்ப்பதற்கு தொலைபேசிகளின் சக்தியை நாங்கள் நம்புகிறோம்.",
                 "t1":"எங்கள் பணி ",

                 "p1":"பிரீமியம் மொபைல் மண்டலத்தில், உலகெங்கிலும் உள்ள மொபைல் ஆர்வலர்களுக்கு வாசிப்பின் மகிழ்ச்சியைக் கொண்டுவருவதில் நாங்கள் ஆர்வமாக உள்ளோம்.<br>புதிய இசைக்குழு போக்குவரத்து வாசகர்களை கவர்ந்திழுக்கும் பல்வேறு வகையான ஃபோன்களின் தொகுப்பை உருவாக்குவதே எங்கள் நோக்கம். ",

                 "t2":"எங்கள் பார்வை",

                 "p2":" நாங்கள் ஒன் ஸ்டாப் மொபைல். எங்கள் சேவை சார்ந்த நிறுவனம், கூட்டாளர்களுக்கு தினசரி அடிப்படையில் சிறந்த தீர்வை வழங்க உறுதிபூண்டுள்ளது, அவர்களின் விருப்பங்கள் மற்றும் தேவைகளை முதன்மையாகக் கொண்டுள்ளது. ஒவ்வொரு கையிலும் இணைப்பு மற்றும் புதுமைகளை வளர்ப்பது.",

                 "t3":" எங்கள் சேகரிப்பு",

                 "p3":" உன்னதமான இலக்கியம் முதல் சமகால புனைகதை, மர்மம், காதல் மற்றும் பல வகைகளை உள்ளடக்கிய, கவனமாகத் தேர்ந்தெடுக்கப்பட்ட நாவல்களை ஆராயுங்கள். எங்களின் அலமாரிகள் காலமற்ற உன்னதமான மற்றும் மறைக்கப்பட்ட கற்களால் நிரம்பியுள்ளன.",

                 "t4":"உங்கள் குழு ",

                 "p4":"Premium Mobile Zoneக்குப் பின்னால் இருக்கும் ஆர்வமுள்ள நபர்களைச் சந்திக்கவும். எங்கள் வாடிக்கையாளர்களுக்கு செழுமையான வாசிப்பு அனுபவத்தை உருவாக்குவதற்கு அர்ப்பணிப்புடன் இருக்கும் ஃபோன் பிரியர்களால் எங்கள் குழு உள்ளது. இலக்கியத்தின் மீதான அன்பை நாங்கள் மதிக்கிறோம், மேலும் அந்த ஆர்வத்தை உங்களுடன் வளர்க்கிறோம். ",

                 "bt":"எங்களை தொடர்பு கொள்ளவும்"
              },

              "sinhala": 
              {
                "title": "Premium Mobile Zone වෙත සාදරයෙන් පිළිගනිමු",
                "description": 
                    "Premium Mobile Zone වෙත සාදරයෙන් පිළිගනිමු, සාහිත්‍යයට ඇති ආදරය ජීවමාන වේ! [1985] හි පිහිටුවන ලද, අපි වාරික ජංගම වෙළඳසැලකට වඩා වැඩි ය; අපි ග්‍රන්ථ නාමාවලිය සඳහා තෝතැන්නක් වන අතර ලිඛිත වචනයට කැප වූ ප්‍රජාවකි. සියලුම රුචි අරුචිකම් සහ මනාප පාඨකයන්ට සපයන විවිධ සහඅපේ මෙහෙයුම ඇතුළත් දුරකථන පරාසයක් පිරිනැමීමට අපි අපවම සපයන්නෙමු. අපගේ කියවීමේ ප්‍රජාවට එක්වන්න! සමාජ මාධ්‍යවල අපව අනුගමනය කරන්න, දුරකථන සමාජවලට සහභාගී වන්න, සහ සබැඳි සහ වෙළඳසැල් යන දෙඅංශයෙන්ම සිදුවන සාහිත්‍ය සිදුවීම් පිළිබඳව යාවත්කාලීනව සිටින්න.",
                 "description2": "අපගේ කණ්ඩායම සුවිශේෂී පාරිභෝගික සේවාවක් සැපයීමට කැපවී සිටී.ඔබට ඔබගේ ඇණවුම සඳහා දුරකථන නිර්දේශයක් හෝ සහායක් අවශ්‍ය වුවද, අපි උදවු කිරීමට මෙහි සිටිමු.2021 දී ආරම්භ කරන ලද, Premium Mobile Zone යනු ජංගම වෙළඳසැලක් පමණක් නොවේ; එය දැඩි පාඨක ප්‍රජාවකි, ලේඛකයින්, සහ කතන්දර කියන්නන්. i, agginations, empathy, සහ අප අවට ලෝකය පිළිබඳ ගැඹුරු අවබෝධයක් පෝෂණය කිරීමට දුරකථනවල බලය අපි විශ්වාස කරමු.",

                 "t1":"අපේ මෙහෙයුම",

                 "p1":"Premium Mobile Zone හි දී, ලොව පුරා සිටින ජංගම දුරකථන ලෝලීන්ට කියවීමේ ප්‍රීතිය ගෙන ඒමට අපි දැඩි උනන්දුවක් දක්වමු.<br>අපගේ මෙහෙවර වන්නේ නව සංගීත කණ්ඩායමක් ප්‍රවාහනය කරන පාඨකයන්ගේ සිත් ඇදගන්නා විවිධ දුරකථන එකතුවක් ලබා දීමයි. ",

                 "t2":"අපගේ දැක්ම",

                 "p2":"අපි One Stop Mobile. අපගේ සේවා-නැඹුරු සංවිධානය, හවුල්කරුවන්ට ඔවුන්ගේ කැමැත්ත සහ අවශ්‍යතා මූලික අවධානයක් ලෙසින්, දිනපතාම හැකි හොඳම විසඳුම ලබා දීමට කැපවී සිටී.සෑම අතකින්ම සම්බන්ධතාව සහ නවෝත්පාදනය පෝෂණය කිරීම.",

                 "t3":"අපගේ එකතුව",

                 "p3":"සාහිත්‍යයේ සිට සමකාලීන ප්‍රබන්ධ, අභිරහස, ප්‍රේම සම්බන්ධය සහ තවත් බොහෝ ප්‍රවර්ග විහිදුවන, අපගේ ප්‍රවේශමෙන් සකස් කරන ලද නවකතා තේරීම ගවේෂණය කරන්න. අපගේ රාක්ක සොයා ගැනීමට බලා සිටින කාලානුරූපී සම්භාව්‍ය සහ සැඟවුණු මැණික්වලින් පිරී ඇත.",

                 "t4":"අපේ කණ්ඩායම",

                 "p4":" Premium Mobile Zone පිටුපස සිටින උද්‍යෝගිමත් පුද්ගලයින් හමුවන්න. අපගේ පාරිභෝගිකයින් සඳහා පොහොසත් කියවීමේ අත්දැකීමක් නිර්මාණය කිරීමට කැපවී සිටින දුරකථන ලෝලීන්ගෙන් අපගේ කණ්ඩායම සමන්විත වේ. අපි සාහිත්‍යයට ඇති ඇල්ම අගය කරන අතර එම ආශාව ඔබ සමඟ හඹා යමු.",
                 
                 "bt":"අපව අමතන්න"
              }
            }
    </script>
</body>

</html>