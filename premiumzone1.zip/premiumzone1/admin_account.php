<div style="display: none;"> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    import swal from 'sweetalert';
</div>

<?php
include 'inc/db.php';
session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="Premium Mobile Zone Logo.png">
  <link rel="icon" type="image/png" href="Premium Mobile Zone Logo.png">
  <title>
    Admin Panel
  </title>

  <!--Fonts and icons-->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />

  <!-- Bootstrap icon -->
   <link  href="assets/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet" />


</head>

<body class="g-sidenav-show  bg-gray-200 ">

  <!-- SideBar Area -->
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header" style="display: flex; justify-content: center;">
      <a class="navbar-brand m-0">
        <img src="Premium Mobile Zone Logo.png" class="navbar-brand-img" alt="main_logo" style="transform: scale(1.8);">
      </a>
    </div>

    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto" style="height:auto;" id="sidenav-collapse-main">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link text-white "  href="admin_page.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-box-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " style="background-color: #0e52aa;" href="admin_categories.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Categories</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_products.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone"></i>
            </div>
            <span class="nav-link-text ms-1">Products</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_orders.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">Pending Oders</span>
          </a>
        </li>


        <li class="nav-item">
          <a class="nav-link text-white " href="admin_complete.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">complete Oders</span>
          </a>
        </li>
        


        <li class="nav-item">
          <a class="nav-link text-white " href="admin_users.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Users</span>
          </a>
        </li>

         <li class="nav-item">
          <a class="nav-link text-white " href="admin_review.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Reviews</span>
          </a>
        </li>



         <li class="nav-item">
          <a class="nav-link text-white " href="admin_messages.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Messages</span>
          </a>
        </li>

   
        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white active" href="admin_account.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">person</i>
            </div>
            <span class="nav-link-text ms-1">User Account</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="index.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">login</i>
            </div>
            <span class="nav-link-text ms-1">Logout</span>
          </a>
        </li>
    </div>
  </aside>
  <!-- End Sidebar -->

  <!-- Main Body -->
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar Area -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Dashboard</h6>
        </nav>
          <ul class="navbar-nav  justify-content-end">

            <li class="nav-item d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Account</span>
              </a>
            </li>

            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>

            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
              </a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->

<!-- Body -->
<div class="container-fluid py-4" data-aos="fade-right" data-aos-duration="500">
      <div class="card">
        <div class="card-header pb-0 px-3" >
          <h6 class="mb-0">Admin Account</h6>
        </div>
        <div class="card-body pt-4 p-3" style="background-color: black;">

          <form method="Post" enctype="multipart/form-data">
            
          <?php

            $user = mysqli_query($conn,"SELECT * FROM users WHERE id = '$_SESSION[admin_id]'");
            $userrow = mysqli_fetch_array($user);
          ?>
            
            <div style="display:flex; justify-content:center;">
              <img src="images/Iyalahan.jpg" class="img-fluid my-3" style="border-radius: 10%; width:25rem;">
            </div>

            <div class="row mb-3">

              <div class="col-md-3" >
                <label for="course_id" class="form-label"style="color: whitesmoke;" >User Name:</label>
                <input type="text" class="form-control" required style="border: 1px solid; padding:5px; color: whitesmoke;" value=" <?php echo $userrow['name']?>" name="txtUsername" >
              </div>

              <div class="col-md-3">
                <label for="student_id" class="form-label" style="color: whitesmoke;">Email:</label>
                <input type="email" class="form-control" required style="border: 1px solid; padding:5px; color: whitesmoke;" value="<?php echo $userrow['email']?>" name="txtEmail">
              </div>

              <div class="col-md-3">
                <label for="student_id" class="form-label" style="color: whitesmoke;">New Password (optional):</label>
                <input type="password" class="form-control"  style="border: 1px solid; padding:5px;" name="txtNewPassword">
              </div>

              <div class="col-md-3">
                <label for="student_id" class="form-label" style="color: whitesmoke;">Current Password:</label>
                <input type="password" class="form-control" required style="border: 1px solid; padding:5px;" name="txtPassword" >
              </div>

            </div>

            <div>
              <input type="submit" class="btn text-white" style="background-color: #726ae3;" value="Update" name="btnupdate" onclick="return confirm('If you may any changes, system automatically logout!')">
              <a href="useradd.php" class="btn text-white" style="background-color: Green;" name="btnadd">Add User</a>
            </div>
          </form>
        </div>
      </div>
    </div>
    <?php
      if(isset($_POST['btnupdate'])){

        if($_POST['txtNewPassword'] == ""){

          $verify = mysqli_query($conn,"SELECT * FROM user WHERE name = '$_SESSION[admin_id]'");
          $verifyrow = mysqli_fetch_assoc($verify);
          
          if(password_verify($_POST['txtPassword'],$verifyrow['Password'])){
            $update = mysqli_query($conn,"UPDATE users SET name='$_POST[txtUsername]',email='$_POST[txtEmail]' WHERE name = '$_SESSION[admin_id]'");
            if($update){
              echo "<script>alert('User information updated successfully!')</script>";
              echo "<script>window.location.href='admin_login.php'</script>";
            }
            else{
              echo "<script>alert('User information update Failed!')</script>";
            }
          }
          else{
            echo "<script>alert('Invaild Password!')</script>";
  
          }

        }
        else{

          $verify = mysqli_query($conn,"SELECT * FROM users WHERE id = '$_SESSION[admin_id]'");
          $verifyrow = mysqli_fetch_assoc($verify);
          
          if(md5($_POST['txtPassword'],$verifyrow['password'])){

            $password = mysqli_real_escape_string($conn,md5($_POST['txtNewPassword']));

            $update = mysqli_query($conn,"UPDATE users SET name='$_POST[txtUsername]',email='$_POST[txtEmail]',password='$password' WHERE id = '$_SESSION[admin_id]'");
            if($update){
              echo "<script>alert('User information updated successfully!')</script>";
              echo "<script>window.location.href='admin_login.php'</script>";
            }
            else{
              echo "<script>alert('User information update Failed!')</script>";
            }
          }
          else{
            echo "<script>alert('Invaild Password!')</script>";
  
          }

        }

      }
    ?>
    <!-- End of Body -->

  </main>
  <!-- Main Body End -->

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
<?php
include 'admin/footer.php';
?>
