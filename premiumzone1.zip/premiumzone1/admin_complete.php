<?php
include 'inc/db.php';
session_start();

 $page = $_SERVER['PHP_SELF'];
 $sec = "10";
 header("Refresh: $sec; url=$page");
 

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
}

if (isset($_POST['update_order'])) {

    $order_update_id = $_POST['order_id'];
    $update_payment = $_POST['update_payment'];
    mysqli_query($conn, "UPDATE `orders` SET payment_status = '$update_payment' WHERE id = '$order_update_id'") or die('query failed');
    $message[] = 'Payment status has been updated!';

}


if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM `orders` WHERE id = '$delete_id'") or die('query failed');
    header('location:admin_orders.php');
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="Premium Mobile Zone Logo.png">
  <link rel="icon" type="image/png" href="Premium Mobile Zone Logo.png">
  <title>
    Admin Panel
  </title>
  <!--Fonts and icons-->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />

  <!-- Bootstrap icon -->
   <link  href="assets/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet" />

 
</head>

<body class="g-sidenav-show  bg-gray-200 ">

  <!-- SideBar Area -->
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header" style="display: flex; justify-content: center;">
      <a class="navbar-brand m-0">
        <img src="Premium Mobile Zone Logo.png" class="navbar-brand-img" alt="main_logo" style="transform: scale(1.8);">
      </a>
    </div>

    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto" style="height:auto;" id="sidenav-collapse-main">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_page.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-box-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_categories.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Categories</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_products.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone"></i>
            </div>
            <span class="nav-link-text ms-1">Products</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_orders.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1"> Pending Oders</span>
          </a>
        </li>


    

        <li class="nav-item">
          <a class="nav-link text-white active" style="background-color: #0e52aa;" href="admin_complete.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">complete Oders</span>
          </a>
        </li>
        

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_users.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Users</span>
          </a>
        </li>

         <li class="nav-item">
          <a class="nav-link text-white " href="admin_review.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Reviews</span>
          </a>
        </li>



         <li class="nav-item">
          <a class="nav-link text-white " href="admin_messages.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Messages</span>
          </a>
        </li>


        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " href="admin_account.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">person</i>
            </div>
            <span class="nav-link-text ms-1">User Account</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="index.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">login</i>
            </div>
            <span class="nav-link-text ms-1">Logout</span>
          </a>
        </li>
    </div>
  </aside>
  <!-- End Sidebar -->

  <!-- Main Body -->
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar Area -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Dashboard</h6>
        </nav>
          <ul class="navbar-nav  justify-content-end">

            <li class="nav-item d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Account</span>
              </a>
            </li>

            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>

            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
              </a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->


    <div class="container-fluid py-4">

      <!---------------------------------------------Body----------------------------------------------------->


<div class="container-fluid py-4">
    <div class="text-center mb-5">
        <h1>PLACED ORDERS</h1>
    </div>

    <div class="row">
        <?php
        $select_orders = mysqli_query($conn, "SELECT * FROM `orders` WHERE payment_status = 'completed'") or die('query failed');
        if (mysqli_num_rows($select_orders) > 0) {
            while ($fetch_orders = mysqli_fetch_assoc($select_orders)) {
        ?>
        <div class="col-12 mb-4">
            <div class="card shadow bg-dark text-light">
                <div class="card-body">
                    <table class="table table-dark table-striped">
                        <tbody>
                            <tr>
                                <th>User ID</th>
                                <td><?php echo $fetch_orders['user_id']; ?></td>
                            </tr>
                            <tr>
                                <th>Placed On</th>
                                <td><?php echo $fetch_orders['placed_on']; ?></td>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <td><?php echo $fetch_orders['name']; ?></td>
                            </tr>
                            <tr>
                                <th>Phone No.</th>
                                <td><?php echo $fetch_orders['number']; ?></td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td><?php echo $fetch_orders['email']; ?></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><?php echo $fetch_orders['address']; ?></td>
                            </tr>
                            <tr>
                                <th>Total Products</th>
                                <td><?php echo $fetch_orders['total_products']; ?></td>
                            </tr>
                            <tr>
                                <th>Total Price</th>
                                <td>Rs. <?php echo $fetch_orders['total_price']; ?> /-</td>
                            </tr>
                            <tr>
                                <th>Payment Method</th>
                                <td><?php echo $fetch_orders['method']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <form action="" method="Post" class="d-flex justify-content-between">
                        <input type="hidden" name="order_id" value="<?php echo $fetch_orders['id']; ?>">
                        <select name="update_payment" class="form-select w-auto text-white bg-dark">
                            <option value="" selected disabled class="text-white bg-dark">
                                <?php echo $fetch_orders['payment_status']; ?>
                            </option>
                            <option value="pending" class="text-white bg-dark">pending</option>
                            <option value="completed" class="text-white bg-dark">completed</option>
                        </select>
                        <div class="d-flex">
                            <input type="submit" value="Update" name="update_order" class="btn btn-primary me-2">
                            <a href="admin_orders.php?delete=<?php echo $fetch_orders['id']; ?>" onclick="return confirm('delete this order?');" class="btn btn-danger">Delete</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo '<p class="text-center">No Orders Placed yet!</p>';
        }
        ?>
    </div>
</div>

<style>
    .form-select option {
        color: white;
        background-color: dark;
    }
</style>

  <!-- Main Body End -->


<?php
include 'admin/footer.php';
?>













    



   
