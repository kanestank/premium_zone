<?php
include("inc/db.php");
session_start();
$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="Premium Mobile Zone Logo.png">
  <link rel="icon" type="image/png" href="Premium Mobile Zone Logo.png">
  <title>
    User Panel
  </title>

<!--Fonts and icons-->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />

  <!-- Bootstrap icon -->
   <link  href="assets/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet" />

  <!-- AOS -->
   <link rel="stylesheet" href="../assets/plugins/aos/aos.css">
  
</head>

<body class="g-sidenav-show  bg-gray-200 ">

  <!-- SideBar Area -->
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header" style="display: flex; justify-content: center;">
      <a class="navbar-brand m-0">
        <img src="Premium Mobile Zone Logo.png" class="navbar-brand-img" alt="main_logo" style="transform: scale(1.8);">
      </a>
    </div>

    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto" style="height:auto;" id="sidenav-collapse-main">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link text-white"  href="user_page.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-box-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>


        <li class="nav-item">
          <a class="nav-link text-white active" style="background-color: #0e52aa;" href="orders.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">Orders</span>
          </a>
        </li>
 
           <li class="nav-item">
          <a class="nav-link text-white " href="home.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Back to Home Page</span>
          </a>
        </li>



        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " href="user_account.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">person</i>
            </div>
            <span class="nav-link-text ms-1">User Account</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="logout.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">login</i>
            </div>
            <span class="nav-link-text ms-1">Logout</span>
          </a>
        </li>
    </div>
  </aside>
  <!-- End Sidebar -->

  <!-- Main Body -->
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar Area -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Dashboard</h6>
        </nav>
          <ul class="navbar-nav  justify-content-end">

            <li class="nav-item d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Account</span>
              </a>
            </li>

            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>

            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
              </a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->

<div class="wrapper">

    <div class="main">
        <main class="content p-3">
            <div class="container-fluid">
                <div class="mb-4 text-center">
                    <h2 class="text-center py-4 fw-bold">Placed Orders</h2>
                </div>
                <div class="row text-dark text-bold">
                    <?php
                    $order_query = mysqli_query($conn, "SELECT * FROM `orders` WHERE user_id = '$user_id'") or die('query failed');
                    if (mysqli_num_rows($order_query) > 0) {
                        while ($fetch_orders = mysqli_fetch_assoc($order_query)) {
                            ?>
                            <div class="col-12 mb-4">
                                <div class="card shadow-sm p-4 bg-white">

                                    <table class="table table-striped">
                                        <tr>
                                            <th>Placed on:</th>
                                            <td>
                                                <?php echo $fetch_orders['placed_on']; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Name:</th>
                                            <td>
                                                <?php echo $fetch_orders['name']; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Number:</th>
                                            <td>
                                                <?php echo $fetch_orders['number']; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Email:</th>
                                            <td>
                                                <?php echo $fetch_orders['email']; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Address:</th>
                                            <td>
                                                <?php echo $fetch_orders['address']; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Payment Method:</th>
                                            <td>
                                                <?php echo $fetch_orders['method']; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Your Orders:</th>
                                            <td>
                                                <span>
                                                    <?php echo $fetch_orders['total_products']; ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Total Price:</th>
                                            <td>
                                                Rs. <?php echo $fetch_orders['total_price']; ?>/-
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Payment Status:</th>
                                            <td>
                                                <span class="<?php echo $fetch_orders['payment_status'] == 'pending' ? 'text-danger' : 'text-success'; ?>">
                                                    <?php echo $fetch_orders['payment_status']; ?>
                                                </span>
                                            </td>
                                        </tr>
                                    </table>

                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p class="text-center text-muted">No Orders Placed yet!</p>';
                    }
                    ?>
                </div>
            </div>
        </main>
    </div>
</div>

        </main>
        

        <?php
        include "user/footer.php";
        ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
