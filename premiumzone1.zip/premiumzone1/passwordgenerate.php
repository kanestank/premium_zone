<?php
session_start();
include "inc/header.php";

?>

<link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style type="text/css">
  .login-forms .login-form-content .button input{
  color: #fff;
  background: #002366;
  border-radius: 6px;

  padding: 0;
  cursor: pointer;
  transition: all 0.4s ease;
}</style>

<!-- Password Reset 8 - Bootstrap Brain Component -->
<div class=" py-3 mt-5"></div>
<section class=" p-3 p-md-4 mt-5 p-xl-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-xxl-11">
        <div class="card border-light-subtle shadow-sm">
          <div class="row g-0">
            <div class="col-12 col-md-6">
              <img class="img-fluid rounded-start w-100 h-100 object-fit-cover" loading="lazy" src="password.jpg" alt="Welcome back you've been missed!">
            </div>
            <div class="col-12 col-md-6 d-flex align-items-center justify-content-center">
              <div class="col-12 col-lg-11 col-xl-10">
                <div class="card-body p-3 p-md-4 p-xl-5">
                  <div class="row">
                    <div class="col-12">
                      <div class="mb-5">
                        <div class="text-center mb-4">
                          <a href="#!">
                            <img src="icon.jpg" alt="BootstrapBrain Logo" width="50" height="150">
                          </a>
                        </div>
                        <h2 class="h4 text-center">YOUR NEW PASSWORD </h2>
                        <h3 class="fs-6 fw-normal text-secondary text-center m-0">Provide Your New Password.</h3>
                      </div>
                    </div>
                  </div>


                  <form method="Post">
                    <div class="row gy-3 overflow-hidden">
                      <div class="col-12">
                        <div class="form-floating mb-3">
                          <input type="text" class="form-control" name="npassword" id="npassword" required>
                          <label for="text" class="form-label">New Password</label>
                        </div>

                          <div class="form-floating mb-3">
                          <input type="password" class="form-control" name="cpassword" id="cpassword" required>
                          <label for="text" class="form-label">Confirm Password</label>
                        </div>

                      </div>
                      <div class="col-12">
                        <div class="d-grid">
                          <input type="submit" name="btnreset" style="display: inline-block; background-color: darkblue; color: #fff; text-align: center; font-size: 1.00rem; padding: 0.5rem 1rem; text-decoration: none; border-radius: 0.25rem;" >

                        </div>
                      </div>
                    </div>
                  </form>
                  <div class="row">
                    <div class="col-12">
                      

                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
  
  if(isset($_POST['btnreset'])){
    include 'inc/db.php';
    if($_POST['npassword'] == $_POST['cpassword']){

      $password = mysqli_real_escape_string($conn,md5($_POST['cpassword']));
      $updatesql = mysqli_query($conn,"UPDATE users SET password = '$password' WHERE id = '$_SESSION[userid]'");

      if($updatesql){
        echo "<script>alert('Password Changed');</script>";
        echo "<script>window.location.href='login.php';</script>";
      }
    }
    else{
      echo "<script>alert('Password Not Matched!');</script>";
    }

  }
?>
