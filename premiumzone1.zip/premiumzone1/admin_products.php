<div style="display: none;"> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    import swal from 'sweetalert';
</div>
<?php
include 'inc/db.php';
session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
   header('location:admin_login.php');
}

if (isset($_POST['add_product'])) {

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $author = $_POST['author'];
   $price = $_POST['price'];
   $quantity=$_POST['quantity'];
   $image = $_FILES['image']['name'];
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = 'uploaded_img/' . $image;

   $select_product_name = mysqli_query($conn, "SELECT name FROM `products` WHERE name = '$name'") or die('query failed');

   if (mysqli_num_rows($select_product_name) > 0) {

             echo "<script>
        swal({
            title: 'OOPS!',
            text: 'PRODUCT NAME ALREADY ADDED!',
            icon: 'error',
            timer: 1500,
            buttons: false
        });
    </script>";
   } else {
      $add_product_query = mysqli_query($conn, "INSERT INTO `products`(cat_id,name, author, price,quantity, image) VALUES($_POST[Cat],'$name', '$author', '$price', '$quantity','$image')") or die('query failed');

      if ($add_product_query) {
         if ($image_size > 2000000) {
             echo "<script>
                    alert('IAMGE SIZE IS TOO LARGE!');
                  </script>";
         } else {
            move_uploaded_file($image_tmp_name, $image_folder);
                 echo "<script>
        swal({
            title: 'Success!',
            text: 'PRODUCT ADDED! SUCCESFULLY!',
            icon: 'success',
            timer: 1500,
            buttons: false
        });
    </script>";   
         }
      } else {
          echo "<script>
                    alert('PRODUCT COULD NOT BE ADDED!');
                  </script>";
      }
   }
}

if (isset($_GET['delete'])) {
   $delete_id = $_GET['delete'];
   $delete_image_query = mysqli_query($conn, "SELECT image FROM `products` WHERE p_id = '$delete_id'") or die('query failed');
   $fetch_delete_image = mysqli_fetch_assoc($delete_image_query);
   unlink('uploaded_img/' . $fetch_delete_image['image']);
   mysqli_query($conn, "DELETE FROM `products` WHERE p_id = '$delete_id'") or die('query failed');
   header('location:admin_products.php');
}

if (isset($_POST['update_product'])) {

   $update_p_id = $_POST['update_p_id'];
   $update_name = $_POST['update_name'];
   $update_price = $_POST['update_price'];
   $update_quantity = $_POST['update_quantity'];

   mysqli_query($conn, "UPDATE `products` SET name = '$update_name', price = '$update_price', quantity = '$update_quantity' WHERE id = '$update_p_id'") or die('query failed');

   $update_image = $_FILES['update_image']['name'];
   $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
   $update_image_size = $_FILES['update_image']['size'];
   $update_folder = 'uploaded_img/' . $update_image;
   $update_old_image = $_POST['update_old_image'];

   if (!empty($update_image)) {
      if ($update_image_size > 2000000) {
         $message[] = 'image file size is too large';
      } else {
         mysqli_query($conn, "UPDATE `products` SET image = '$update_image' WHERE id = '$update_p_id'") or die('query failed');
         move_uploaded_file($update_image_tmp_name, $update_folder);
         unlink('uploaded_img/' . $update_old_image);
      }
   }

   header('location:admin_products.php');

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="Premium Mobile Zone Logo.png">
  <link rel="icon" type="image/png" href="Premium Mobile Zone Logo.png">
  <title>
    Admin Panel
  </title>
    <!--Fonts and icons-->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />

  <!-- Bootstrap icon -->
   <link  href="assets/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet" />

  
  <style type="text/css">
   /* Modal header */
  #add .modal-header {
    background-color: #192841; /* Change the background color */
    color: #fff; /* Change the text color */
  }

  /* Modal body */
  #add .modal-body {
    background-color: #f8f9fa; /* Change the background color */
     /* Change the text color */

  }
   
   /* Customize the background color of input fields */
.modal-content .form-control {
    background-color: #f1f3f5; /* Change this to your preferred background color */
    color: #495057; /* Change this to your preferred text color */
    border-color: #ced4da; /* Change this to your preferred border color */
}

/* Customize the color of input field placeholder text */
.modal-content .form-control::placeholder {
    color:  #000000 /* Change this to your preferred placeholder color */
}


/* Optional: Customize the focus color of input fields */
.modal-content .form-control:focus {
    border-color: #80bdff; /* Change this to your preferred focus border color */
    box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25); /* Change this to your preferred focus shadow color */
}

  /* Modal footer */
  #add .modal-footer {
    background-color: #e9ecef; /* Change the background color */
    color: #212529; /* Change the text color */
  }

 
  
  /* Custom styles for form elements */
  #add .form-floating input,
  #add .form-floating select {
    border-color: #007bff; /* Change border color of form inputs */
  }
  
  #add .form-floating label {
     color:  #000000/* Change the label color */
  }
  
  #add .btn-close {
    filter: invert(1); /* Optional: Invert color of close button for visibility */
    color: white;
  }
  </style>
  
</head>

<body class="bg-gray-200">

  <!-- SideBar Area -->
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header" style="display: flex; justify-content: center;">
      <a class="navbar-brand m-0">
        <img src="Premium Mobile Zone Logo.png" class="navbar-brand-img" alt="main_logo" style="transform: scale(1.8);">
      </a>
    </div>

    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto" style="height:auto;" id="sidenav-collapse-main">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link text-white" href="admin_page.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-box-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white  " href="admin_categories.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Categories</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white active" style="background-color: #0e52aa;" href="admin_products.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone"></i>
            </div>
            <span class="nav-link-text ms-1">Products</span>
          </a>
        </li>

         

       <li class="nav-item">
          <a class="nav-link text-white " href="admin_orders.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">Pending Oders</span>
          </a>
        </li>


        <li class="nav-item">
          <a class="nav-link text-white " href="admin_complete.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">complete Oders</span>
          </a>
        </li>
        


        <li class="nav-item">
          <a class="nav-link text-white " href="admin_users.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Users</span>
          </a>
        </li>

         <li class="nav-item">
          <a class="nav-link text-white " href="admin_review.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Reviews</span>
          </a>
        </li>



         <li class="nav-item">
          <a class="nav-link text-white " href="admin_messages.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Messages</span>
          </a>
        </li>


        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " href="admin_account.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">person</i>
            </div>
            <span class="nav-link-text ms-1">User Account</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="index.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">login</i>
            </div>
            <span class="nav-link-text ms-1">Logout</span>
          </a>
        </li>
    </div>
  </aside>
  <!-- End Sidebar -->

  <!-- Main Body -->
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar Area -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Dashboard</h6>
        </nav>
          <ul class="navbar-nav  justify-content-end">

            <li class="nav-item d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Account</span>
              </a>
            </li>

            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>

            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
              </a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->


<!-- BODY -->
<div class="main">
  
   <!-- Admin Users Start -->

   <div class="container-xxl py-5" style="min-height:90vh;">
      <div class="container">

         <div class="col-12 d-flex justify-content-between wow fadeInUp" data-wow-delay="0.1s">
            <h1 class="">All Phones</h1>
            <button type="button" class="btn btn-primary btn-md" data-bs-toggle="modal" data-bs-target="#add">
               Add New Phone
            </button>
         </div>

      
         <div class="row mt-5">

            <table class="table border">
               <thead>
                  <tr class="text-center">
                     <th scope="col">Sr. No.</th>
                     <th scope="col">Image</th>
                     <th scope="col">Category</th>
                     <th scope="col">Name</th>
                     <th scope="col">Description</th>
                     <th scope="col">Qunatity</th>
                     <th scope="col">Price</th>
                     <th scope="col" colspan="2">Action</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                  $select_products = mysqli_query($conn, "SELECT * FROM products JOIN category ON products.cat_id = category.cat_id") or die('query failed');
                  if (mysqli_num_rows($select_products) > 0) {
                     while ($fetch_products = mysqli_fetch_assoc($select_products)) {
                        ?>

                        <tr class="text-center">
                           <th scope="row" class="py-3">
                              <?php echo $fetch_products['p_id']; ?>
                           </th>

                           <td class="py-3 "><img src="uploaded_img/<?php echo $fetch_products['image']; ?>" alt=""
                                 width="60px"></td>

                           <td class="py-3 ">
                              <?php echo $fetch_products['cat_icon']; ?>
                           </td>

                           <td class="py-3 ">
                              <?php echo $fetch_products['name']; ?>
                           </td>
                           <td class="py-3">
                              <?php echo $fetch_products['author']; ?>
                           </td>
                            <td class="py-3">
                              <?php echo $fetch_products['quantity'];?>
                           </td>
                           <td class="py-3">Rs.
                              <?php echo $fetch_products['price']; ?> /-
                           </td>

                           <td class="py-3"><a href="product_update.php?update=<?php echo $fetch_products['p_id']; ?>"
                                 class="option-btn"><i class="bi bi-pencil-square"></i></a></td>

                           <td class="py-3"><a href="admin_products.php?delete=<?php echo $fetch_products['p_id']; ?>"
                                 class="text-danger" onclick="return confirm('delete this product?');"><i class="bi bi-trash3"></i></a></td>
                        </tr>
                        <?php
                     }
                  } else {
                     echo '<p class="empty">no products added yet!</p>';
                  }
                  ?>


               </tbody>
            </table>
         </div>

      </div>
   </div>


   <!-- Modal -->
   <div class="modal fade" id="add"  aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
         <div class="modal-content">
            <div class="modal-header">
               <h1 class="modal-title fs-5" id="exampleModalLabel">Add Phone</h1>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
               <form method="POST" enctype="multipart/form-data">

                  <div class="row g-3">

                     <div class="col-12">
                        <div class="form-control">
                           <input type="file" name="image" accept="image/jpg, image/jpeg, image/png">
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-floating">
                           <input type="text" class="form-control" id="name" placeholder="Phone Name" name="name"
                              required>
                           
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="form-floating">
                           <label for="name" style="margin-top: 10px;">Categorey</label>
                           <select name="Cat">
                           <?php
                              $sql = mysqli_query($conn,"SELECT * FROM category");

                              while($row = mysqli_fetch_assoc($sql)){
            
                           ?>
                              <option value="<?php echo "$row[cat_id]";?>">
                                 <?php echo "$row[cat_icon]";?> 
                              </option>

                           <?php
                        }
                           ?>
                           </select>
      
                        </div>
                     </div>

                     <div class="col-md-6">
                        <div class="form-floating">
                           <input type="text" class="form-control" id="author" placeholder="Description" name="author"
                              required>
                          
                        </div>
                     </div>
                     <div class="col-12">
                        <div class="form-floating">
                           <input type="number" class="form-control" id="price" placeholder="Price" name="price"
                              required>
                          
                        </div>
                     </div>
                      <div class="col-12">
                        <div class="form-floating">
                           <input type="number" class="form-control" id="quantity" placeholder="Quantity" name="quantity"
                              required>
                           
                        </div>
                     </div>

                     <div class="col-12">
                        <button class="btn btn-primary w-100 py-3" name="add_product" type="submit">Add Phone</button>
                     </div>

                  </div>
               </form>
            </div>


         </div>
      </div>
   </div>



   <!-- Admin Users End -->
</div>
</div>
</body>

</html>

   <!-- Admin Users End -->
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>

<?php
include 'admin/footer.php';
?>






