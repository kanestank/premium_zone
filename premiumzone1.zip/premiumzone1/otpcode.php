<?php
session_start();
include "inc/header.php";
?>

<link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style type="text/css">
  .login-forms .login-form-content .button input{
  color: #fff;
  background: #002366;
  border-radius: 6px;

  padding: 0;
  cursor: pointer;
  transition: all 0.4s ease;
}

 body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f5;
        }
        .verification-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .verification-container h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }
        .verification-container p {
            margin-bottom: 20px;
            font-size: 16px;
            color: #666;
        }
        .otp-input {
            width: 50px;
            height: 50px;
            margin: 0 5px;
            font-size: 24px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .verify-btn {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 18px;
            color: #fff;
            background-color: #4A60F6;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .verify-btn:hover {
            background-color: #3c4ed8;
        }
        .resend-link {
            display: block;
            margin-top: 15px;
            font-size: 14px;
            color: #4A60F6;
            text-decoration: none;
        }
        .resend-link:hover {
            text-decoration: underline;
        }

</style>
<form method="post">
<!-- Password Reset 8 - Bootstrap Brain Component -->
<div class=" py-3 mt-5"></div>
<section class=" p-3 p-md-4 mt-5 p-xl-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-xxl-11">
        <div class="card border-light-subtle shadow-sm">
          <div class="row g-0">
            <div class="col-12 col-md-6">
              <img class="img-fluid rounded-start w-100 h-100 object-fit-cover" loading="lazy" src="otp.jpg" alt="Welcome back you've been missed!">
            </div>
            <div class="col-12 col-md-6 d-flex align-items-center justify-content-center">
              <div class="col-12 col-lg-11 col-xl-10">
                <div class="card-body p-3 p-md-4 p-xl-5">
                  <div class="row">
                    <div class="col-12">
                      <div class="mb-5">
                        <div class="text-center mb-4">
                          <a href="#!">
                            <img src="icon.jpg" alt="BootstrapBrain Logo" width="50" height="150">
                          </a>
                        </div>
                        <h2 class="h4 text-center">YOUR OTP CODE</h2>
                        <h3 class="fs-6 fw-normal text-secondary text-center m-0">Provide the OTP Code associated with your account to recover your password.</h3>
                      </div>
                    </div>
                  </div>

                    <div class="verification-container">
                        <h2>Mobile Phone Verification</h2>
                        <p>Enter the 4-digit verification code that was sent to your phone number.</p>
                        
                        <div>
                            <input type="text" class="otp-input" maxlength="1" name="otp1">
                            <input type="text" class="otp-input" maxlength="1" name="otp2">
                            <input type="text" class="otp-input" maxlength="1" name="otp3">
                            <input type="text" class="otp-input" maxlength="1" name="otp4">
                       
                        
                         <button type = "submit" name = "btnconfirm"style="display: inline-block; background-color: darkblue; color: #fff; text-align: center; font-size: 1.00rem; padding: 0.5rem 1rem; text-decoration: none; border-radius: 0.25rem;"   >Verify</button>
                       </div>
                    </div>

                    </form>

                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php
if(isset($_POST['btnconfirm'])){
  include 'inc/db.php';

  $otpstring = $_POST['otp1'].$_POST['otp2'].$_POST['otp3'].$_POST['otp4'];

  if($_SESSION['otp'] == $otpstring){
    echo "<script>window.location.href='passwordgenerate.php'</script>";
  }
  else{
    echo "<script>alert('Invaild OTP Number Check Again!')</script>";

  }
}

?>
       
<?php
include "inc/footer.php";
?>