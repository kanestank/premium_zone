<div style="display: none;"> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    import swal from 'sweetalert';
</div>

<?php

include("inc/db.php");
session_start();
echo "<div style='display:none;'>";
$_SESSION['ID'] = $_GET['ID'];
echo "</div>";

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}

if (isset($_POST['add_to_cart'])) {

    if($_POST['t1'] < $_POST['product_quantity']){
         echo "<script>
        swal({
            title: 'error!',
            text: 'Only Available $_POST[t1] Stocks',
            icon: 'error',
            timer: 1400,
            buttons: false
        });
    </script>";
    }
    else{

    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    $product_quantity = $_POST['product_quantity'];

    $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    $sqlpid =  mysqli_query($conn, "SELECT * FROM products WHERE name = '$product_name'") or die('query failed');
    $rowsqlpid = mysqli_fetch_assoc($sqlpid);


    if (mysqli_num_rows($check_cart_numbers) > 0) {
        $message[] = 'Already Added to cart!';
    } else {
        mysqli_query($conn, "INSERT INTO `cart`(p_id,user_id, name, price, quantity, image) VALUES('$rowsqlpid[p_id]','$user_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
        $message[] = 'Book Added to cart!';
    }

}
}


?>


<?php
include "inc/header.php";
?>
<div class="py-3 mt-5"></div>
<div class="container-xxl py-3 mt-5">

    <div class="container ">
        <div class="row mt-2">
            <!-- Books Start -->
            <div class="col-12 wow fadeInUp overflow-auto" data-wow-delay="0.1s">

                <div class="container">
                    <div class="text-center wow fadeInUp" data-wow-delay="0.1s">

                        <h3 class="mb-2" style="color: #8e44ad;">All Phones</h3>
                    </div>


                        <form method="POST">
                            <select name="mainlist" class="form-control mt-5">
                                <option value="all" selected>--All Category--</option>

                            <?php
                                $cate = mysqli_query($conn,"SELECT * FROM category");
                                while($caterow = mysqli_fetch_assoc($cate)){
                            ?> 

                                <option value="<?php echo $caterow['cat_id'];?>"><?php echo $caterow['cat_icon'];?></option>

                            <?php
                            }
                            ?>
                            </select>
                            <input type="submit" name="btnsubmit" class="btn btn1 rounded-3 mt-2 text-white" value="Search">
                            </form>

                            <?php
                                if (isset($_POST['btnsubmit'])) {
                                    unset($_SESSION['ID']);
                                    if(isset($_GET['msg'])){

                            ?>
                            <div class="row g-4 mt-3">

                            <?php

                            if(isset($_GET['msg'])){
                            include("inc/db.php");

                            if($_POST['mainlist'] == 'all'){
                            $select_products = mysqli_query($conn, "SELECT * FROM `products`") or die('query failed');
                            }
                            else{
                            $select_products = mysqli_query($conn, "SELECT * FROM `products` WHERE cat_id = '$_POST[mainlist]'") or die('query failed');
                            }
                            if (mysqli_num_rows($select_products) > 0) {
                                while ($fetch_products = mysqli_fetch_assoc($select_products)) {

                                    if($fetch_products['quantity'] > 0){
                                    ?>
                                <div class="col-lg-3 col-md-6 col-sm-12">

                                    <div class="card shadow ">
                                        <a href="#">
                                            <img src="uploaded_img/<?php echo $fetch_products['image']; ?>" class="img-fluid"
                                                alt="..." style="height:400px;" width="100%">
                                        </a>
                                        <div class="card-body p-4">
                                            <h5 class="card-title"><a href="" class="text-dark">
                                                    <?php echo $fetch_products['name']; ?>
                                                </a></h5>
                                            <p>
                                                <?php echo $fetch_products['author']; ?>
                                            </p>

                                            <form action="" method="POST">
                                                <div class="d-flex justify-content-between mb-3">
                                                    <small class="py-1 px-1 fw-bold fs-6 text-center">Rs.
                                                        <?php echo $fetch_products['price']; ?>/-
                                                    </small><br>
                                                    <input type="number" min="1" name="product_quantity" value="1"
                                                        class="qty form-control" style="width:100px;">
                                                    <input type="hidden" name="t1" value="<?php echo $fetch_products['quantity'];?>"
                                                    class="qty form-control" style="width:100px;">
                                                    
                                                </div>
                                                <div>
                                                    <input type="hidden" name="pid"
                                                        value="<?php echo $fetch_products['p_id']; ?>">
                                                    <input type="hidden" name="product_name"
                                                        value="<?php echo $fetch_products['name']; ?>">
                                                    <input type="hidden" name="product_price"
                                                        value="<?php echo $fetch_products['price']; ?>">
                                                    <input type="hidden" name="product_image"
                                                        value="<?php echo $fetch_products['image']; ?>">
                                                    
                                                    <input type="submit" value="Add to cart" name="add_to_cart"
                                                        class="btn1 text-white w-100 p-2">
                                                </div>
                                            </form>

                                        </div>
                                    </div>

                                </div>

                                <?php
                                        }
                                        else{
                                ?>

                                    <div class="col-lg-3 col-md-6 col-sm-12" style="opacity: 0.5; cursor: no-drop;">

                                    <div class="card shadow ">
                                        <a href="#">
                                            <img src="uploaded_img/<?php echo $fetch_products['image']; ?>" class="img-fluid"
                                                alt="..." style="height:400px; cursor: no-drop;" width="100%">
                                        </a>
                                        <div class="card-body p-4">
                                            <h5 class="card-title"><a href="" class="text-dark">
                                                    <?php echo $fetch_products['name']; ?>
                                                </a></h5>
                                            <p>
                                                <?php echo $fetch_products['author']; ?>
                                            </p>


                                            <form action="" method="POST">
                                                <div class="d-flex justify-content-between mb-3">
                                                    <small class="py-1 px-1 fw-bold fs-6 text-center">Rs.
                                                        <?php echo $fetch_products['price']; ?>/-
                                                    </small><br>
                                                    <input type="number" min="1" name="product_quantity" value="1"
                                                        class="qty form-control" style="width:100px;">
                                                        <input type="hidden" name="t1" value="<?php echo $fetch_products['quantity'];?>"
                                                    class="qty form-control" style="width:100px;">
                                                    
                                                </div>
                                                <div>
                                                    <input type="hidden" name="pid"
                                                        value="<?php echo $fetch_products['p_id']; ?>">
                                                    <input type="hidden" name="product_name"
                                                        value="<?php echo $fetch_products['name']; ?>">
                                                    <input type="hidden" name="product_price"
                                                        value="<?php echo $fetch_products['price']; ?>">
                                                    <input type="hidden" name="product_image"
                                                        value="<?php echo $fetch_products['image']; ?>">

                                                    <input type="submit" value="No Stock Available" name="add_to_cart"
                                                        class="btn1 text-white w-100 p-2" style="cursor: no-drop; pointer-events: none; background: red;">
                                                </div>

                                            </form>

                                        </div>
                                    </div>

                                </div>


                                <?php
                                        }
                                    }
                                }
                                else {
                                echo '<p class="empty">No products added yet!</p>';
                                }
                                }
                                }
                                }
                                ?>


                    <div class="py-4">
                        <?php
                        if (isset($message)) {
                            foreach ($message as $message) {
                                echo '
                                <div class="message alert alert-success d-flex justify-content-between mt-3">
                                    <span>' . $message . '</span>
                                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                                </div>
                                ';
                            }
                        }
                        ?>
                    </div>

                    <?php
                        if(isset($_SESSION['ID'])){
                    ?>
                    <div class="row g-4">
                        <?php
                        include("inc/db.php");
                        $select_products = mysqli_query($conn, "SELECT * FROM `products` WHERE cat_id = $_GET[ID]") or die('query failed');
                        if (mysqli_num_rows($select_products) > 0) {
                            while ($fetch_products = mysqli_fetch_assoc($select_products)) {
                                ?>
                                <div class="col-lg-3 col-md-6 col-sm-12">

                                    <div class="card shadow ">
                                        <a href="#">
                                            <img src="uploaded_img/<?php echo $fetch_products['image']; ?>" class="img-fluid"
                                                alt="..." style="height:400px;" width="100%">
                                        </a>
                                        <div class="card-body p-4">
                                            <h5 class="card-title"><a href="" class="text-dark">
                                                    <?php echo $fetch_products['name']; ?>
                                                </a></h5>
                                            <p>
                                                <?php echo $fetch_products['author']; ?>
                                            </p>


                                            <form action="" method="POST">
                                                <div class="d-flex justify-content-between mb-3">
                                                    <small class="py-1 px-1 fw-bold fs-6 text-center">Rs.
                                                        <?php echo $fetch_products['price']; ?>/-
                                                    </small>
                                                    <input type="number" min="1" name="product_quantity" value="1"
                                                        class="qty form-control" style="width:100px;">
                                                        <input type="hidden" name="t1" value="<?php echo $fetch_products['quantity'];?>"
                                                    class="qty form-control" style="width:100px;">
                                                </div>
                                                <div>
                                                    <input type="hidden" name="product_name"
                                                        value="<?php echo $fetch_products['name']; ?>">
                                                    <input type="hidden" name="product_price"
                                                        value="<?php echo $fetch_products['price']; ?>">
                                                    <input type="hidden" name="product_image"
                                                        value="<?php echo $fetch_products['image']; ?>">
                                                    <input type="submit" value="Add to cart" name="add_to_cart"
                                                        class="btn1 text-white w-100 p-2">
                                                </div>
                                            </form>

                                        </div>
                                    </div>

                                </div>
                                <?php
                            }
                        } else {
                            echo '<p class="empty">No products added yet!</p>';
                        }
                    }
                        ?>

                    </div>
                    </div>

                </div>

            </div>
            <!-- Books End -->
        </div>
    </div>
</div>
<footer id="footer" style="margin-top: 30rem;">
    <h2>Mobile Shop &copy; all rights reserved<a href="team.php"> NDICT STUDENTS</a></h2>
  </footer>

    
<?php
include "inc/footer.php";
?>
