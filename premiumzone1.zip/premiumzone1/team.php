<?php
//include 'inc/db.php';

//session_start();

//$user_id = $_SESSION['user_id'];

//if (!isset($user_id)) {
    //header('location:login.php');
//}
//?>
<?php
    include "inc/header.php";
?>

<!-- Team Start -->
 <style type="text/css">
        :root {
    --primary: darkblue;
    --light: #F0FBFC;
    --dark: #181d38;
}

.fw-medium {
    font-weight: 600 !important;
}

.fw-semi-bold {
    font-weight: 700 !important;
}

.team-item img {
    transition: .5s;
}

.team-item:hover img {
    cursor: pointer;
    transform: scale(1.1);
}

/*** Testimonial ***/
.testimonial-carousel::before {
    position: absolute;
    content: "";
    top: 0;
    left: 0;
    height: 100%;
    width: 0;
    background: linear-gradient(to right, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
    z-index: 1;
}

.testimonial-carousel::after {
    position: absolute;
    content: "";
    top: 0;
    right: 0;
    height: 100%;
    width: 0;
    background: linear-gradient(to left, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
    z-index: 1;
}

@media (min-width: 768px) {
    .testimonial-carousel::before,
    .testimonial-carousel::after {
        width: 200px;
    }
}

@media (min-width: 992px) {
    .testimonial-carousel::before,
    .testimonial-carousel::after {
        width: 300px;
    }
}

.testimonial-carousel .owl-item .testimonial-text,
.testimonial-carousel .owl-item.center .testimonial-text * {
    transition: .5s;
}

.testimonial-carousel .owl-item.center .testimonial-text {
    background: var(--primary) !important;
}

.testimonial-carousel .owl-item.center .testimonial-text * {
    color: #FFFFFF !important;
}

.testimonial-carousel .owl-dots {
    margin-top: 24px;
    display: flex;
    align-items: flex-end;
    justify-content: center;
}

.testimonial-carousel .owl-dot {
    position: relative;
    display: inline-block;
    margin: 0 5px;
    width: 15px;
    height: 15px;
    border: 1px solid #CCCCCC;
    transition: .5s;
}

.testimonial-carousel .owl-dot.active {
    background: var(--primary);
    border-color: var(--primary);
}
.bg{

    background: #dae9fe;
}
</style>
</head>

<body>
    
  <div class="container-xxl py-5 mt-5">
    <div class="py-2 mt-5"></div>
    <div class="container">
        <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
            <h6 class="section-title bg-white text-center text-darkblue px-3">Testimonial</h6>
            <h1 class="mb-5">Owner</h1>
        </div>
        <div class="row g-4 justify-content-center"> <!-- Added justify-content-center -->
            <div class="col-lg-3 col-md-6 wow fadeInUp mx-auto" data-wow-delay="0.1s"> <!-- Added mx-auto -->
                <div class="team-item bg">
                    <div class="overflow-hidden">
                        <img class="img-fluid" src="images/Iyalahan.jpg" alt="OwnerImg">
                    </div>
                    <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                        <div class="bg-light d-flex justify-content-center pt-2 px-1">
                            <a class="btn btn1-sm-square btn1 mx-1" href="https://www.facebook.com/profile.php?id=100009193732870&mibextid=LQQJ4d"><i class="fab fa-facebook-f" style="color:white;"></i></a>
                            <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="bi bi-whatsapp" style="color:white;"></i></a>
                            <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="fab fa-instagram" style="color:white;"></i></a>
                        </div>
                    </div>
                    <div class="text-center p-4">
                        <h5 class="mb-0">S.Iyalahan</h5>
                        <small>Shop Owner</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Testimonial Start -->
        <div class="container-xxl py-2 mt-4">
             <div class= "py-2 mt-2"></div>
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-darkblue px-3">Testimonial</h6>
                <h1 class="mb-5">Our Team</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="images/kanestan.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn1-sm-square btn1 mx-1" href="https://www.facebook.com/vettivel.vairamuthu?mibextid=LQQJ4d"><i class="fab fa-facebook-f"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href="http://wa.me/94750925149"><i class="bi bi-whatsapp"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="fab fa-instagram"style="color:white;"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Kanestan</h5>
                            <small>Full Stake Developer</small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="images/usama.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn1-sm-square btn1 mx-1" href="https://www.facebook.com/share/PYacoxY1simgREnL/?mibextid=qi2Omg"><i class="fab fa-facebook-f"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href="https://wa.me/message/TZ4ERX3YHAIFL1"><i class="bi bi-whatsapp"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href="https://www.instagram.com/muhamed_usama_2002?igsh=NTFrdzN2aTNhaG0y"><i class="fab fa-instagram"style="color:white;"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Usama</h5>
                            <small>Full Stake Developer</small>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="images/afra.jpeg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn1-sm-square btn1" href="https://www.facebook.com/share/yGHhbYvSxitfK2Vw/?mibextid=qi2Omg"><i class="fab fa-facebook-f"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1" href="https://wa.me/qr/3YG43UCCDUDMB1"><i class="bi bi-whatsapp"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1" href="https://www.instagram.com/mrs_azee29?utm_source=qr&igsh=MTgyejZzOWxpcDV4"><i class="fab fa-instagram"style="color:white;"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Afra</h5>
                            <small>Full Stake Developer</small>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="images/sharmi.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="fab fa-facebook-f"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href="https://wa.me/qr/LD4SLU5VG3YOL1"><i class="bi bi-whatsapp"style="color:white;"></i></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="fab fa-instagram"style="color:white;"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Sharmila</h5>
                            <small>Full Stake Developer</small>
                        </div>
                    </div>
                </div>

                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="images/anoxshan.jpg" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="fab fa-facebook-f"style="color:white;"></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="bi bi-whatsapp"style="color:white;"></i></i></a>
                                <a class="btn btn1-sm-square btn1 mx-1" href=""><i class="fab fa-instagram"style="color:white;"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Anoxshans</h5>
                            <small>Full Stake Developer</small>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- Testimonial End -->
<!-- Team End -->

<footer id="footer">
    <h2>Mobile Shop &copy; all rights reserved<a href="team.php"> NDICT STUDENTS</a></h2>
  </footer>

<?php
include "inc/footer.php";
?>