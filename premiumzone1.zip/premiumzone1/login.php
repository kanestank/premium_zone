<?php
include "inc/db.php";
include "inc/messages.php";

session_start();

if (isset($_POST['login'])) {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = mysqli_real_escape_string($conn, md5($_POST['password']));

    $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('query failed');

    if (mysqli_num_rows($select_users) > 0) {

        $row = mysqli_fetch_assoc($select_users);

       if ($row['user_type'] == 'user') {

            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_id'] = $row['id'];
            header('location:home.php');

        }

    } else {
        $message[] = 'incorrect email or password!';
    }

}

?>

<?php
include "inc/header.php";
?>

   <style type="text/css">
     /* Google Font Link */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins" , sans-serif;
}
body{
  background: #FFFFFF;
}
.login-container{
  margin-right: auto;
  margin-left: auto;
  margin-top:12rem;
  position: relative;
  max-width: 850px;
  width: 100%;
  background: #fff;
  padding: 40px 30px;
  box-shadow: 0 5px 10px rgba(0,0,0,0.2);
  perspective: 2700px;
  border-radius: 10px;
}
.login-container .login-cover{
  position: absolute;
  top: 0;
  left: 50%;
  height: 100%;
  width: 50%;
  z-index: 98;
  transition: all 1s ease;
  transform-origin: left;
  transform-style: preserve-3d;
}
.login-container #flip:checked ~ .login-cover{
  transform: translatex(-450px);
}
.login-container .login-cover .front,
 .login-container .login-cover .back{
  position: absolute;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  border-top-right-radius: 20px;
 
}

.login-cover .back{
 
  backface-visibility: hidden;
}
.login-container .login-cover::before,
.login-container .login-cover::after{
  content: '';
  position: absolute;
  height: 100%;
  width: 100%;
  background: ;
  opacity: 0.5;
  z-index: 12;
}
.login-container .login-cover::after{
  opacity: 0.3;
  transform: scalex(-1);
  backface-visibility: hidden;
}
.login-container .login-cover img{
  position: absolute;
  height: 100%;
  width: 100%;
  object-fit: cover;
  z-index: 10;
  

}
.login-container .login-cover.flip-img {
      transform: scalex(-1);
      }
.login-container .login-cover .text{
  position: absolute;
  z-index: 130;
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.login-cover .text .text-1,
.login-cover .text .text-2{
  font-size: 26px;
  font-weight: 600;
  color: #fff;
  text-align: center;
}
.login-cover .text .text-2{
  font-size: 15px;
  font-weight: 500;
}
.login-container .login-forms{
  height: 100%;
  width: 100%;
  background: #fff;
}
.login-container .login-form-content{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.login-form-content .login-form,
.login-form-content .signup-form{
  width: calc(100% / 2 - 25px);
}
.login-forms .login-form-content .title{
  position: relative;
  font-size: 36px;
  font-weight: 500;
  color: #333;

}
.login-forms .login-form-content.title:after{
    content: " ";
    height: 5px;
    width: 50px;
    background-color: #002366;
    position: absolute;
    bottom:0;
    margin-top: 10px;
  }

.login-forms .signup-form  .title:before{
  width: 20px;
}

.login-forms .login-form-content .input-boxe{
  margin-top: 30px;
}
.login-forms .login-form-content .input-box{
  display: flex;
  align-items: center;
  height: 50px;
  width: 100%;
  margin: 10px 0;
  position: relative;
}
.login-form-content .input-box input{
  height: 100%;
  width: 100%;
  outline: none;
  border: none;
  padding: 0 30px;
  font-size: 16px;
  font-weight: 500;
  border-bottom: 2px solid rgba(0,0,0,0.2);
  transition: all 0.3s ease;
}
.login-form-content .input-box input:focus,
.login-form-content .input-box input:valid{
  border-color: #7d2ae8;
}
.login-form-content .input-box i{
  position: absolute;
  color: #7d2ae8;
  font-size: 17px;
}
.login-forms .login-form-content .text{
  font-size: 14px;
  font-weight: 500;
  color: #333;
}
.login-forms .login-form-content .text a{
  text-decoration: none;
}
.login-forms .login-form-content .text a:hover{
  text-decoration: underline;
}
.login-forms .login-form-content .button{
  color: #fff;
  margin-top: 40px;
}
.login-forms .login-form-content .button input{
  color: #fff;
  background: #726ae3;
  border-radius: 6px;

  padding: 0;
  cursor: pointer;
  transition: all 0.4s ease;
}
.login-forms .login-form-content .button input:focus{
  background: #FFFFFF;
  color:#002366;
  outline-color: #002366;
}
.login-forms .login-form-content label{
  color: #5b13b9;
  cursor: pointer;
}
.login-forms .login-form-content label:hover{
  text-decoration: underline;
}
.login-forms .login-form-content .login-text,
.login-forms .login-form-content .sign-up-text{
  text-align: center;
  margin-top: 25px;
}
.login-container #flip{
  display: none;
}

.login-logo{
  display: none;
}
.login-link{
  color:lightblue;
}
@media (max-width: 730px) {
 .login-logo{
    display: inline;
    width: 6rem;
  }

.login-logodiv{
   
    display: flex;
    align-items: center;
    justify-content: center;

  }

 .login-forms .login-form-content .title{
    display: flex;
    align-items: center;
    justify-content: center;
  }
.title{
    display: flex;
    align-items: center;
    justify-content: center;
  }
 
  .login-container .login-cover{
    display: none;
  }
.login-form-content .login-form,
  .login-form-content .signup-form{
    width: 100%;

  }
.login-form-content .signup-form{
    display: none;
  }
  .login-container #flip:checked ~ .login-forms .signup-form{
    display: block;
  }
  .login-container #flip:checked ~ .login-forms .login-form{
    display: none;
  }
}

.input100:user-invalid{
  
}

   </style>


  <div class="login-container" mt=>
    <input type="checkbox" id="flip">
    <div class="login-cover">
      <div class="front">
        <img src="logo.jpg" alt="">
      </div>
      <div class="back">
        <img class="backImg flip-img " src="logo.jpg" alt="">
      </div>
    </div>
    <div class="login-forms">
        <div class="login-form-content">
          <div class="login-form">
            <div class="login-logodiv">
            <img src="Premium Mobile Zone Logo.png" class="login-logo">
          </div>
            <div class="title">Login</div>
             <?php
                        if (isset($message)) {
                            foreach ($message as $message) {
                                echo '
                                <div class="message alert alert-danger d-flex justify-content-between mt-4">
                                    <span>' . $message . '</span>
                                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                                </div>
                                ';
                            }
                        }
                        ?>
           
          <form  method="post">
            <div class="input-boxes">
              <div class="input-box">
                <i class="fas fa-envelope"style="color:#726ae3;"></i>    
                <input class="input100" type="email" name="email" placeholder=" E-mail" required autocomplete="off">
              </div>
              <div class="input-box">
                <i class="fas fa-lock"style="color:#726ae3;"></i>
                <input class="input100" type="password" name="password" placeholder=" password" required autocomplete="off">
              </div>
              <div class="text"><a href="forgot.php">Forgot password?</a></div>
              <div class="button input-box">
                <input type="submit" value="Login" name="login">
              </div>
              <div class="text sign-up-text">Don't have an account? <label for="flip">Signup</label></div>
            </div>
        </form>
      </div>


<?php
include("inc/db.php");
// include("inc/functions.php");

if (isset($_POST['signup'])) {

    // Database connection (ensure $conn is properly initialized)
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = $_POST['password'];
    $cpass = $_POST['password2'];
    $user_type = $_POST['user_type'];

    // Function to validate strong passwords
    function isStrongPassword($password) {
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
    }

    // Check if passwords match
    if ($pass != $cpass) {
        echo "<script>
            swal({
                title: 'Error!',
                text: 'Confirm password does not match!',
                icon: 'error',
                timer: 3000,
                buttons: false
            });
        </script>";
    } elseif (!isStrongPassword($pass)) {
        // Check if password is strong
        echo "<script>
            swal({
                title: 'Error!',
                text: 'Password must be at least 8 characters long and include uppercase letters, lowercase letters, numbers, and special characters!',
                icon: 'error',
                timer: 3000,
                buttons: false
            });
        </script>";
    } else {
        // Check if email already exists
        $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email'") or die('Query failed');

        if (mysqli_num_rows($select_users) > 0) {
            echo "<script>
                swal({
                    title: 'Error!',
                    text: 'Email is already registered!',
                    icon: 'error',
                    timer: 3000,
                    buttons: false
                });
            </script>";
        } else {
          
            $hashed_pass = md5($pass);

            $insert_user = mysqli_query($conn, "INSERT INTO `users` (name, email, password, user_type) VALUES ('$name', '$email', '$hashed_pass', '$user_type')") or die('Query failed');
            
            if ($insert_user) {
                echo "<script>
                    swal({
                        title: 'Success!',
                        text: 'Registration successful!',
                        icon: 'success',
                        timer: 3000,
                        buttons: false
                    });
                </script>";
            }
        }
    }
}
?>

        <div class="signup-form">
           <div class="login-logodiv">
            <img src="Premium Mobile Zone Logo.png" class="login-logo">
          </div>
          <div class="title">Signup</div>
         
        <form  method="post">
            <div class="input-boxes">
              <div class="input-box">
                <i class="fas fa-user" style="color:#726ae3;"></i>
               <input class="input100" type="text" name="name" placeholder="name" required autocomplete="off">
              </div>
              <div class="input-box">
                <i class="fas fa-envelope" style="color:#726ae3;"></i>
                <input class="input100" type="email" name="email" placeholder=" E-mail" required autocomplete="off">
              </div>
              <div class="input-box">
                <i class="fas fa-lock" style="color:#726ae3;"></i>
              <input class="input100" type="password" name="password" placeholder="Password" required autocomplete="off">
              </div>
             <div class="input-box">
                <i class="fas fa-lock" style="color:#726ae3;"></i>
            <input class="input100" type="password" name="password2" placeholder="Re-Enter password" required autocomplete="off">
              </div>

              <div class="col-12">
                            <div class="form-floating">
                                <select name="user_type" id="" class="form-select">
                                    <option value="user">User</option>
                                </select>

                            </div>
                        </div>

              </div>
              <div class="button input-box">
                <input type="submit" value="Signup" name="signup">
              </div>
              <div class="text sign-up-text">Already have an account? <label class="login-link" for="flip">Login</label></div>
            </div>
      </form>
    </div>
    </div>
    </div>
  </div>


<?php
include "inc/footer.php";
?>



