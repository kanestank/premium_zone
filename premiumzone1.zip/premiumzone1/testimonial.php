<?php
include 'inc/db.php';
session_start();

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}
?>

<?php
include "inc/header.php";
?>

<title>Testimonials</title>

<style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+HK&display=swap');
   body {
        font-family: 'Noto Sans HK', sans-serif;
        background: #fff;
    }
    .slider {
        margin-bottom: 30px;
        position: relative;
    }
    .slider .owl-item.active.center .slider-card {
        transform: scale(1.15);
        opacity: 1;
        background: darkblue;
        color: #fff;
    }
    .slider-card {
        background: #fff;
        padding: 0px;
        margin: 50px 15px 90px 15px;
        border-radius: 5px;
        box-shadow: 0 15px 45px -20px rgb(0 0 0 / 73%);
        transform: scale(0.9);
        opacity: 0.5;
        transition: all 0.1s;
    }
    .slider-card img {
        border-radius: 5px 5px 0 0;
    }
    .owl-nav .owl-prev {
        position: absolute;
        top: calc(50% - 25px);
        left: 0;
        opacity: 1;
        font-size: 30px !important;
        z-index: 1;
    }
    .owl-nav .owl-next {
        position: absolute;
        top: calc(50% - 25px);
        right: 0;
        opacity: 1;
        font-size: 30px !important;
        z-index: 1;
    }
    .owl-dots {
        text-align: center;
    }
    .owl-dots .owl-dot {
        height: 10px;
        width: 10px;
        border-radius: 10px;
        background: #ccc !important;
        margin-left: 3px;
        margin-right: 3px;
        outline: none;
    }
    .owl-dots .owl-dot.active {
        background: #0e52aa !important;
    }
</style>

<body>
<div class="container-xxl py-2 mt-1 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="py-4">
             <?php
            if (isset($message)) {
                foreach ($message as $message) {
                    echo '<div class="message alert alert-success d-flex justify-content-between">
                    <span>' . $message . '</span>
                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                </div>
                ';
                }
            }
            ?>
        </div>
        <section id="slider" class="pt-5 py-3 mt-5">
            <div class="container">
                <div class="slider">
                    <div class="owl-carousel">
                        <?php
                        $select_review = mysqli_query($conn, "SELECT * FROM `review`") or die('query failed');
                        if (mysqli_num_rows($select_review) > 0) {
                            while ($fetch_review = mysqli_fetch_assoc($select_review)) {
                                ?>
                                <div class="slider-card">
                                    <div class="d-flex justify-content-center align-items-center mb-1">
                                       
                                        <img src="human.jpg" alt="usersimages" />
                                    </div>
                                    <h5 class="mb-0 text-center text-white"><?php echo $fetch_review["name"]; ?></h5>
                                    <p class="text-center p-4 text-white"><?php echo $fetch_review["review"]; ?></p>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p class="text-center">No Reviews added yet!</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>

        </section>
        <div class="row mt-1">
            <div class="col-12 mt-1">
                <center>
                    <!-- Modified Button Section -->
                    <a href="add_review.php" class="btn btn1 text-white p-2">Add Your Review</a>
                </center>
            </div>
        </div>
    </div>
</div>


<?php
include "inc/footer.php";
?>

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            autoplay: true,
            autoplayTimeout: 1500,
            autoplayHoverPause: true,
            center: true,
            navText: [
                "<i class='fa fa-angle-left'></i>",
                "<i class='fa fa-angle-right'></i>"
            ],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 3
                }
            }
        });
    });
</script>
</body>
</html>
<div>
<footer id="footer">
    <h2>Restraunt &copy; all rights reserved<a href="team.php"> NDICT STUDENTS</a></h2>
  </footer>
  </div>