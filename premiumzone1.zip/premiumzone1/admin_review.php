<?php
include 'inc/db.php';
session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
}

if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM `review` WHERE r_id = '$delete_id'") or die('query failed');
    header('location:admin_review.php');
}


?>

<?php
include "inc/messages.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="Premium Mobile Zone Logo.png">
  <link rel="icon" type="image/png" href="Premium Mobile Zone Logo.png">
  <title>
    Admin Panel
  </title>

    <!--Fonts and icons-->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />

  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />

  <!-- Bootstrap icon -->
   <link  href="assets/bootstrap-icons/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>

  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">

  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/material-dashboard.css?v=3.0.0" rel="stylesheet" />

 
</head>

<body class="g-sidenav-show  bg-gray-200 ">

  <!-- SideBar Area -->
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3   bg-gradient-dark" id="sidenav-main">
    <div class="sidenav-header" style="display: flex; justify-content: center;">
      <a class="navbar-brand m-0">
        <img src="Premium Mobile Zone Logo.png" class="navbar-brand-img" alt="main_logo" style="transform: scale(1.8);">
      </a>
    </div>

    <hr class="horizontal light mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto" style="height:auto;" id="sidenav-collapse-main">
      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link text-white "  href="admin_page.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-box-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_categories.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone-fill"></i>
            </div>
            <span class="nav-link-text ms-1">Categories</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_products.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-phone"></i>
            </div>
            <span class="nav-link-text ms-1">Products</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_orders.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">Pending Oders</span>
          </a>
        </li>


        <li class="nav-item">
          <a class="nav-link text-white " href="admin_complete.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-earbuds"></i>
            </div>
            <span class="nav-link-text ms-1">complete Oders</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="admin_users.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Users</span>
          </a>
        </li>

         <li class="nav-item">
          <a class="nav-link text-whiteactive" style="background-color: #0e52aa;" href="../admin/admin_review.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Reviews</span>
          </a>
        </li>



         <li class="nav-item">
          <a class="nav-link text-white " href="admin_messages.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
            <i class="bi bi-person-badge"></i>
            </div>
            <span class="nav-link-text ms-1">Messages</span>
          </a>
        </li>


        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs text-white font-weight-bolder opacity-8">Account pages</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white " href="admin_account.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">person</i>
            </div>
            <span class="nav-link-text ms-1">User Account</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link text-white " href="index.php">
            <div class="text-white text-center me-2 d-flex align-items-center justify-content-center">
              <i class="material-icons opacity-10">login</i>
            </div>
            <span class="nav-link-text ms-1">Logout</span>
          </a>
        </li>
    </div>
  </aside>
  <!-- End Sidebar -->

  <!-- Main Body -->
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar Area -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Dashboard</h6>
        </nav>
          <ul class="navbar-nav  justify-content-end">

            <li class="nav-item d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-user me-sm-1"></i>
                <span class="d-sm-inline d-none">Account</span>
              </a>
            </li>

            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>

            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
              </a>
            </li>

          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->


<div class="main">
    <!-- Admin Products Start -->
    <div class="container-xxl py-5" style="min-height:90vh;">
        <div class="container">
            <div class="text-center">
                <h1 class="mb-5 ">REVIEWS</h1>
            </div>

          

            <div class="row">
                <?php
                $select_review = mysqli_query($conn, "SELECT * FROM `review`") or die('query failed');
                if (mysqli_num_rows($select_review) > 0) {
                    while ($fetch_review = mysqli_fetch_assoc($select_review)) {

                        ?>
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm h-100">

                            <div class="card-body">
                                <h2 class="card-title text-capitalize">
                                    <?php echo $fetch_review['name']; ?>
                                </h2>

                                <p class="text-muted">
                                    <?php echo $fetch_review['review']; ?>
                                </p>

                                <a href="admin_review.php?delete=<?php echo $fetch_review['r_id']; ?>"
                                    onclick="return confirm('Delete this Review?');"
                                    class="btn btn-primary w-100    ">Delete</a>
                            </div>
                        </div>
                        </div>
                        <?php
                    }
                    ;
                } else {
                    echo '<p class="text-center">You have no reviews!</p>';
                }
                ?>

            </div>

        </div>
    </div>


    <!-- Admin Products End -->

    <?php
    include "admin/footer.php";
    ?>

</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
